"""
PROPERTY RIGHTS module: granting, conditionality, concentration and critical assets (DKP-2-ASSETS-001 §3.2, §4, §5, §7, §9).

Subjects ask for Property Rights over assets.  ASSETS grants a right only under the §4 conditions
(a-d) and never on prior possession, inheritance without obligation transfer or a contract detached
from impact alone; every right is conditional (§3.2, §5): when a condition later fails, the right is
degraded.  Assets of the §9 categories are designated Non-Privatizable or Conditionally Privatizable
and held only under stewardship, always revocable.  Accumulations declared as increasing systemic
fragility, coercive dominance or cascading harm draw one of the §7 responses.

Revocation, reallocation, disputes and Justice-driven access are module economic_access.  What the
text leaves open is declared:
  * H-PR-1: §9 lists the categories without saying which are Non-Privatizable and which Conditionally
    Privatizable; the designation is an input per category;
  * H-PR-2: §7 thresholds are "derived from impact metrics" but not given; whether an accumulation
    triggers §7 is a declared flag (ASSETS-7-01 is reclassified l8_parameter);
  * the §4 conditions (non-negative net justice contribution, use within impact bounds, axiomatic
    priorities, mitigation capacity) are declared values of each request.
Time unit: DTI-Day.
"""

from __future__ import annotations

from typing import Any, Dict, List

from lab.core.bus import EventLog, Message
from lab.core.checks import FAIL, NOT_APPLICABLE, PASS, CheckResult
from lab.core.module import LabModule, ModuleResult
from lab.core.schema import LabInputError, resolve

CRITICAL = ("biosphere_critical", "water_air_ecology", "informational_commons")          # ASSETS §9
CATEGORIES = ("ordinary",) + CRITICAL
SOLE_BASES = ("prior_possession", "inheritance_without_obligations", "contract_only")     # ASSETS §4
BASES = ("conditions",) + SOLE_BASES
RESPONSES = ("graduated_restriction", "enforced_divestment", "reallocation")              # ASSETS §7
PERSISTENCE = ["justice contribution non-negative", "use within impact constraints", "restitution obligations satisfied"]   # §5

FAULTS = {
    "absolute_right": "a granted right is recorded as permanent and stays in force when its conditions fail",
    "grant_by_possession": "a right is granted on prior possession alone",
    "privatize_commons": "a §9 asset is granted as ordinary private property",
    "ignore_concentration": "an accumulation declared as increasing systemic fragility draws no §7 response",
    "no_suspension_on_failure": "a right stays in force after a §5 condition fails (only the suspension is skipped)",
    "anonymous_holding": "a granted right is registered without its Subject and kept out of public audit",
    "assets_overrides": "ASSETS waives failed conditions and grants the right at its board's discretion",
    "only_requesting_right": "a negative Justice result of a Subject suspends only the right whose request scheduled it",
    # checkable cores of provisions whose open point remains (review КТ7-GPT-01)
    "assets_feed_ptl": "an ASSETS decision is fed back into a PTL observation",
    "transfer_drops_attribution": "a transferred right no longer names the Subject responsible for it",
    "price_threshold": "the concentration threshold follows the market value of the holding",
}

REQUEST = {"type": "object", "fields": {
    "id": {"type": "str"},
    "subject": {"type": "str"},
    "asset": {"type": "str"},
    "category": {"type": "enum", "values": list(CATEGORIES), "default": "ordinary"},
    "basis": {"type": "enum", "values": list(BASES), "default": "conditions"},
    "justice_contribution": {"type": "number", "min": -1000, "max": 1000, "default": 1.0},
    "use_within_bounds": {"type": "bool", "default": True},
    "axioms_ok": {"type": "bool", "default": True},
    "mitigation_capacity": {"type": "bool", "default": True},
    "condition_fails_day": {"type": "int", "min": -1, "max": 3650, "default": -1},
    # a failed Justice contribution concerns the Subject (all its rights); a failed use condition concerns this right only
    "failure_kind": {"type": "enum", "values": ["justice_contribution", "asset_use"], "default": "justice_contribution"}}}
HOLDING = {"type": "object", "fields": {
    "subject": {"type": "str"},
    "assets": {"type": "int", "min": 1, "max": 10 ** 6, "default": 1},
    "increases_fragility": {"type": "bool", "default": False},
    "response": {"type": "enum", "values": list(RESPONSES), "default": "graduated_restriction"},
    "impact_exposure": {"type": "number", "min": 0, "max": 10 ** 6, "default": 1.0},
    "market_value": {"type": "number", "min": 0, "max": 10 ** 12, "default": 1000.0}}}
TRANSFER = {"type": "object", "fields": {"request": {"type": "str"}, "to": {"type": "str"},
                                         "day": {"type": "int", "min": 0, "max": 3650}}}


def threshold_of(impact_exposure: float, market_value: float, faults) -> float:
    """Lab stand-in for the §7 concentration threshold, derived from impact metrics (no value in the corpus, H-PR-2)."""
    if "price_threshold" in faults:
        return round(market_value / 100.0, 9)
    return round(10.0 / (1.0 + impact_exposure), 9)
REQUESTS_DEFAULT = [
    {"id": "q1", "subject": "coop_a", "asset": "workshop", "condition_fails_day": 6},
    {"id": "q2", "subject": "estate_b", "asset": "farmland", "basis": "prior_possession"},
    {"id": "q3", "subject": "heir_c", "asset": "warehouse", "basis": "inheritance_without_obligations"},
    {"id": "q4", "subject": "utility_d", "asset": "aquifer", "category": "water_air_ecology"},
    {"id": "q5", "subject": "firm_e", "asset": "quarry", "justice_contribution": -2.0},
]
HOLDINGS_DEFAULT = [{"subject": "grid_holder", "assets": 40, "increases_fragility": True, "response": "enforced_divestment"},
                    {"subject": "coop_a", "assets": 2}]


def conditions(q: Dict[str, Any]) -> Dict[str, bool]:
    return {"a_non_negative_justice": q["justice_contribution"] >= 0, "b_use_within_bounds": q["use_within_bounds"],
            "c_axioms": q["axioms_ok"], "d_mitigation_capacity": q["mitigation_capacity"]}


def run(r: Dict[str, Any]) -> EventLog:
    faults = set(r["faults"])
    log = EventLog("DTI-Day", tie_rule="observation < evaluation < decision < action < notice; then event_id")
    order = {"observation": 0, "evaluation": 1, "decision": 2, "action": 3, "notice": 4}
    n = {"i": 0}

    def put(kind, source, k, value, prov=()):
        n["i"] += 1
        return log.append(Message(event_id=f"{source.lower()}-{k:04d}-{n['i']:05d}", kind=kind, source=source, arrived_at=k,
                                  measured_at=k if kind == "observation" else None,
                                  decided_at=k if kind in ("decision", "action") else None, value=value,
                                  provenance=tuple(prov), order=order[kind]))

    rights = {}
    for q in r["requests"]:
        req = put("observation", "REQUEST", 0, dict(q))
        cond = conditions(q)
        ev = put("evaluation", "ASSETS", 0, {"request": q["id"], "conditions": cond, "basis": q["basis"]}, [req.event_id])
        sole = q["basis"] in SOLE_BASES and not ("grant_by_possession" in faults and q["basis"] == "prior_possession")
        if q["category"] in CRITICAL:
            designation = r["critical_designation"][q["category"]]
            put("notice", "ASSETS", 0, {"asset": q["asset"], "designation": designation, "category": q["category"]}, [req.event_id])
        override = "assets_overrides" in faults and not sole and not all(cond.values())
        if override:
            put("notice", "ASSETS", 0, {"request": q["id"], "exemption": "failed conditions waived", "justice_override": True,
                                        "by": "asset board discretion"}, [ev.event_id])
        elif sole or not all(cond.values()):
            why = (f"basis '{q['basis']}' alone (§4)" if sole else "conditions " + ", ".join(c for c, ok in cond.items() if not ok))
            put("decision", "ASSETS", 0, {"request": q["id"], "granted": False, "reason": why}, [ev.event_id])
            continue
        if q["category"] in CRITICAL and r["critical_designation"][q["category"]] == "non_privatizable" \
                and "privatize_commons" not in faults:
            put("decision", "ASSETS", 0, {"request": q["id"], "granted": False, "reason": "Non-Privatizable asset (§9)"}, [ev.event_id])
            continue
        form = "ordinary" if q["category"] == "ordinary" or "privatize_commons" in faults else "stewardship"
        g = put("decision", "ASSETS", 0, {"request": q["id"], "granted": True, "subject": q["subject"], "asset": q["asset"],
                                          "form": form, "granted_by": "system rule (ASSETS §4 a-d)",
                                          "persistence_conditions": [] if "absolute_right" in faults else PERSISTENCE,
                                          "revocable": "absolute_right" not in faults,
                                          **({"permanent": True} if "absolute_right" in faults else {})}, [ev.event_id])
        rights[q["id"]] = g
        anon = "anonymous_holding" in faults
        put("notice", "REGISTER", 0, {"right": g.event_id, "asset": q["asset"], "subject": None if anon else q["subject"],
                                      "public": not anon}, [g.event_id])
    suspended = set()
    for k in range(0, r["horizon_days"]):                 # day 0 included: a failure on the day of the grant (КТ6-GPT-02)
        for q in r["requests"]:
            if q["condition_fails_day"] != k or q["id"] not in rights:
                continue
            if q["failure_kind"] == "justice_contribution":
                # a Justice result concerns the Subject: every active right of that Subject loses the §5 condition (КТ7-GPT-02)
                f = put("observation", "JUSTICE", k, {"subject": q["subject"], "net_justice_contribution": -1.0,
                                                      "after_grant": True})
                hit = [q] if "only_requesting_right" in faults else \
                    [x for x in r["requests"] if x["subject"] == q["subject"] and x["id"] in rights]
            else:
                # a condition of this right only (use within impact constraints), declared as such
                f = put("observation", "IMPACT/USE", k, {"right": rights[q["id"]].event_id, "request": q["id"],
                                                         "condition": "use within impact constraints", "met": False})
                hit = [q]
            if "absolute_right" in faults or "no_suspension_on_failure" in faults:
                continue
            for x in hit:
                if x["id"] not in suspended:
                    suspended.add(x["id"])
                    put("action", "ASSETS", k, {"right": rights[x["id"]].event_id, "status": "suspended",
                                                "reason": "a §5 condition failed"}, [f.event_id, rights[x["id"]].event_id])
    for t in r["transfers"]:
        if t["request"] in rights and t["day"] < r["horizon_days"]:
            g = rights[t["request"]]
            frm = g.value["subject"]
            put("action", "ASSETS", t["day"], {"transfer": g.event_id, "from": frm, "to": t["to"],
                                               "responsible_subject": None if "transfer_drops_attribution" in faults else frm},
                [g.event_id])
    if "assets_feed_ptl" in faults and rights:
        g = next(iter(rights.values()))
        put("observation", "PTL", 0, {"reading": "asset-derived adjustment"}, [g.event_id])
    for hd in r["holdings"]:
        h = put("observation", "IMPACT", 0, {"holder": hd["subject"], "assets": hd["assets"],
                                             "increases_fragility": hd["increases_fragility"]})
        put("evaluation", "ASSETS", 0, {"holder": hd["subject"], "concentration_threshold":
                                        threshold_of(hd["impact_exposure"], hd["market_value"], faults),
                                        "basis": "impact exposure (stand-in, H-PR-2)"}, [h.event_id])
        if hd["increases_fragility"] and "ignore_concentration" not in faults:
            put("action", "ASSETS", 0, {"holder": hd["subject"], "response": hd["response"],
                                        "basis": "impact-based concentration (§7; thresholds not given, H-PR-2)"}, [h.event_id])
    return log


def failure_days(r: Dict[str, Any], msgs, granted, req) -> Dict[str, List[int]]:
    """Days on which a §5 condition of each granted right failed, from the inputs (a Justice failure concerns every right
    of its Subject, a use failure one right) and from the records that actually arrived (КТ7-GPT-02)."""
    out: Dict[str, set] = {q: set() for q in granted}
    for q, x in req.items():
        d = x["condition_fails_day"]
        if d < 0 or q not in granted:
            continue
        if x.get("failure_kind", "justice_contribution") == "justice_contribution":
            for q2 in granted:
                if req[q2]["subject"] == x["subject"]:
                    out[q2].add(d)
        else:
            out[q].add(d)
    for m in msgs:
        if m.source == "JUSTICE" and m.value.get("net_justice_contribution", 0) < 0:
            for q2, g in granted.items():
                if g.value["subject"] == m.value.get("subject"):
                    out[q2].add(m.arrived_at)
        elif m.source == "IMPACT/USE" and m.value.get("met") is False:
            for q2, g in granted.items():
                if g.event_id == m.value.get("right"):
                    out[q2].add(m.arrived_at)
    return {q: sorted(d for d in v if 0 <= d < r["horizon_days"]) for q, v in out.items()}


def responded(msgs, right_id: str, k: int) -> bool:
    return any(x.source == "ASSETS" and x.value.get("right") == right_id and x.arrived_at <= k
               and x.value.get("status") in ("suspended", "restricted", "degraded") for x in msgs)


def core_checks(r, log, msgs, req, granted, fdays, v, na) -> List[CheckResult]:
    """Clear parts of provisions whose open point remains (reading record, partial_check; review КТ7-GPT-01)."""
    out = []
    if req:
        cond_fail = {q: [c for c, ok in conditions(x).items() if not ok] for q, x in req.items()}
        bad = [f"{q}: granted although {', '.join(cond_fail[q])} failed" for q in granted if cond_fail[q]]
        out.append(v("ASSETS-4-01", "grant_on_all_four_conditions", bad,
                     f"{len(granted)} right(s), each granted with all four §4 conditions true",
                     "{n} rights granted with a failed §4 condition"))
        bypass = [f"{q}: granted although the axiomatic condition failed" for q in granted if "c_axioms" in cond_fail[q]]
        bypass += [f"{m.event_id}: {k}" for m in msgs if m.source == "ASSETS" for k in ("exemption", "justice_override")
                   if k in m.value]
        out.append(v("ASSETS-1-02", "no_axiom_bypass_or_override", bypass,
                     "no asset decision passed an axiomatic limit or overrode an impact or Justice input",
                     "{n} bypasses of axiomatic limits or overrides of upstream outputs"))
    else:
        for rid, chk in (("ASSETS-4-01", "grant_on_all_four_conditions"), ("ASSETS-1-02", "no_axiom_bypass_or_override")):
            out.append(na(rid, chk, "ASSETS decisions", "no request to decide"))
    assets_ids = {m.event_id for m in msgs if m.source == "ASSETS"}
    back = [m.event_id for m in msgs if m.source in ("PTL", "JUSTICE", "IMPACT", "IMPACT/USE") and set(m.provenance) & assets_ids]
    out.append(v("ASSETS-2-01", "downstream_of_ptl", back,
                 "inputs flow from PTL, IMPACT and JUSTICE into ASSETS; no upstream record is derived from an ASSETS record",
                 "{n} upstream records derived from ASSETS") if assets_ids else
               na("ASSETS-2-01", "downstream_of_ptl", "ASSETS records", "no ASSETS record in this experiment"))
    if granted:
        jus = [(q, k) for q in granted for k in fdays[q]
               if any(m.source == "JUSTICE" and m.arrived_at == k and m.value.get("subject") == granted[q].value["subject"]
                      for m in msgs) or (req[q]["condition_fails_day"] == k and req[q].get("failure_kind") == "justice_contribution")]
        bad = [f"{q}: kept after a negative Justice contribution on day {k}" for q, k in jus if not responded(msgs, granted[q].event_id, k)]
        out.append(v("ASSETS-5-01", "justice_condition_persists", bad,
                     f"{len(jus)} negative Justice contribution(s), each followed by a response on every right of the Subject",
                     "{n} rights kept after the Justice condition failed") if jus else
                   na("ASSETS-5-01", "justice_condition_persists", "Justice condition", "no negative Justice contribution"))
    else:
        out.append(na("ASSETS-5-01", "justice_condition_persists", "Justice condition", "no right granted"))
    tr = [m for m in msgs if m.source == "ASSETS" and m.value.get("transfer")]
    out.append(v("ASSETS-6-01", "transfer_keeps_attribution",
                 [m.event_id for m in tr if m.value.get("responsible_subject") != m.value.get("from")],
                 f"{len(tr)} transfer(s), each still naming the Subject responsible for the asset",
                 "{n} transfers that drop the responsible Subject") if tr else
               na("ASSETS-6-01", "transfer_keeps_attribution", "transfers", "no transfer in this experiment"))
    th = [m for m in msgs if m.source == "ASSETS" and "concentration_threshold" in m.value]
    if th:
        moved = dict(r, holdings=[dict(h, market_value=h["market_value"] * 3 + 1) for h in r["holdings"]])
        again = {m.value["holder"]: m.value["concentration_threshold"] for m in run(moved).messages()
                 if m.source == "ASSETS" and "concentration_threshold" in m.value}
        bad = [f"{m.value['holder']}: {m.value['concentration_threshold']} -> {again.get(m.value['holder'])}" for m in th
               if again.get(m.value["holder"]) != m.value["concentration_threshold"]]
        out.append(v("ASSETS-7-02", "threshold_from_impact", bad,
                     f"{len(th)} concentration threshold(s) unchanged when only market value changes (metamorphic)",
                     "{n} thresholds that follow market value"))
    else:
        out.append(na("ASSETS-7-02", "threshold_from_impact", "concentration thresholds", "no holding"))
    crit = [q for q in granted if req[q]["category"] in CRITICAL]
    out.append(v("ASSETS-9-02", "commons_always_revocable", [q for q in crit if not granted[q].value.get("revocable")],
                 f"{len(crit)} §9 asset(s) held under stewardship and always revocable", "{n} §9 assets made irrevocable")
               if crit else na("ASSETS-9-02", "commons_always_revocable", "§9 assets", "none granted"))
    return out


def checks(r: Dict[str, Any], log: EventLog) -> List[CheckResult]:
    msgs = log.messages()
    out: List[CheckResult] = []

    def v(rid, chk, bad, ok, no):
        return CheckResult(rid, chk, FAIL if bad else PASS, no.format(n=len(bad)) if bad else ok,
                           evidence={"violations": bad[:10]} if bad else {})

    def na(rid, chk, what, why):
        return CheckResult(rid, chk, NOT_APPLICABLE, what, applicability=why)

    req = {m.value["id"]: m.value for m in msgs if m.source == "REQUEST"}
    dec = {m.value["request"]: m for m in msgs if m.source == "ASSETS" and m.kind == "decision"}
    granted = {q: m for q, m in dec.items() if m.value["granted"]}
    fdays = failure_days(r, msgs, granted, req)
    bad = []
    for q, m in granted.items():
        g = m.value
        if g.get("permanent") or not g.get("revocable") or not g.get("persistence_conditions"):
            bad.append(f"{q}: right recorded as absolute or permanent")
        # failure days from the inputs and from the records that arrived (0 counts: a failure on the grant day)
        for k in fdays[q]:
            if not responded(msgs, m.event_id, k):
                bad.append(f"{q}: right kept after a §5 condition failed on day {k}")
    out.append(v("ASSETS-3.2-01", "property_right_conditional", bad,
                 f"{len(granted)} right(s) granted by system rule, conditional, revocable and suspended when a condition failed",
                 "{n} rights that are absolute, permanent or not contingent") if granted else
               na("ASSETS-3.2-01", "property_right_conditional", "Property Rights", "no right granted"))
    sole = [q for q, x in req.items() if x["basis"] in SOLE_BASES]
    out.append(v("ASSETS-4-02", "no_grant_on_sole_basis", [f"{q}: granted on {req[q]['basis']}" for q in sole if q in granted],
                 f"{len(sole)} request(s) resting on prior possession, inheritance without obligations or a contract alone refused",
                 "{n} rights granted on an excluded basis") if sole else
               na("ASSETS-4-02", "no_grant_on_sole_basis", "excluded bases", "no request rests on an excluded basis"))
    crit = [q for q, x in req.items() if x["category"] in CRITICAL]
    des = {m.value["asset"]: m.value["designation"] for m in msgs if m.source == "ASSETS" and m.value.get("designation")}
    bad = [f"{q}: no designation" for q in crit if req[q]["asset"] not in des]
    bad += [f"{q}: granted as {granted[q].value['form']}" for q in crit if q in granted
            and (granted[q].value["form"] != "stewardship" or not granted[q].value.get("revocable"))]
    bad += [f"{q}: Non-Privatizable asset granted" for q in crit if q in granted and des.get(req[q]["asset"]) == "non_privatizable"]
    out.append(v("ASSETS-9-01", "critical_assets_designated", bad,
                 f"{len(crit)} §9 asset(s) designated ({', '.join(sorted(set(des.values()))) or '-'}; split by H-PR-1) and held only "
                 "under revocable stewardship", "{n} §9 assets privatized or not designated") if crit else
               na("ASSETS-9-01", "critical_assets_designated", "§9 assets", "no request concerns a §9 asset"))
    # returned to work after the reading of the Codex-draft open points (review of checkpoint 6)
    if granted:
        bad = [f"{q}: right recorded as absolute or not revocable" for q, m in granted.items()
               if m.value.get("permanent") or not m.value.get("revocable")]
        bad += [f"{q}: granted without the §4 contribution conditions ({req[q]['basis']})" for q in granted
                if req[q]["basis"] in SOLE_BASES or not all(conditions(req[q]).values())]
        out.append(v("ASSETS-1-01", "property_is_conditional_allocation", bad,
                     f"{len(granted)} right(s), each a revocable allocation of control resting on the §4 contribution conditions",
                     "{n} rights that are absolute or not justified by contribution"))
        reg = {m.value["right"]: m.value for m in msgs if m.source == "REGISTER"}
        bad = [f"{q}: not registered" for q, m in granted.items() if m.event_id not in reg]
        bad += [f"{q}: register entry without its Subject or not public" for q, m in granted.items()
                if m.event_id in reg and (not reg[m.event_id]["subject"] or not reg[m.event_id]["public"])]
        out.append(v("ASSETS-12-01", "ownership_registered_auditable_bound", bad,
                     f"{len(granted)} right(s) registered, open to public audit and bound to an identified Subject",
                     "{n} holdings not registered, not auditable or not bound to a Subject"))
    else:
        out.append(na("ASSETS-1-01", "property_is_conditional_allocation", "Property Rights", "no right granted"))
        out.append(na("ASSETS-12-01", "ownership_registered_auditable_bound", "ownership structures", "no right granted"))
    fails = [(q, k) for q in granted for k in fdays[q]]          # the conditions that actually failed (КТ7-GPT-02)
    bad = [f"{q}: no degradation, restriction or suspension by day {k}" for q, k in fails
           if not responded(msgs, granted[q].event_id, k)]
    out.append(v("ASSETS-5-02", "failure_triggers_degradation", bad,
                 f"{len(fails)} condition failure(s), each followed automatically by degradation, restriction or suspension",
                 "{n} failures without an automatic response") if fails else
               na("ASSETS-5-02", "failure_triggers_degradation", "condition failures", "no granted right had a condition fail"))
    bad = [f"{m.value['request']}: {k}" for m in msgs if m.source == "ASSETS" for k in ("exemption", "justice_override", "by")
           if k in m.value and m.kind == "notice"]
    bad += [m.event_id for m in msgs if m.source in ("IMPACT", "JUSTICE") and any(log.get(p).source == "ASSETS" for p in m.provenance)]
    out.append(v("ASSETS-13-01", "no_cross_layer_override", bad,
                 "ASSETS applied Justice and impact inputs as given: no waiver, exemption, override or discretionary grant",
                 "{n} cross-layer overrides by ASSETS") if req else
               na("ASSETS-13-01", "no_cross_layer_override", "ASSETS decisions", "no request to decide"))
    out += core_checks(r, log, msgs, req, granted, fdays, v, na)
    flagged = [m for m in msgs if m.source == "IMPACT" and m.value["increases_fragility"]]
    resp = {m.value["holder"] for m in msgs if m.source == "ASSETS" and m.value.get("response") in RESPONSES}
    out.append(v("ASSETS-7-01", "concentration_response", [m.value["holder"] for m in flagged if m.value["holder"] not in resp],
                 f"{len(flagged)} accumulation(s) declared as increasing systemic fragility drew a §7 response "
                 "(the threshold itself is not given: H-PR-2)", "{n} flagged accumulations without a §7 response") if flagged else
               na("ASSETS-7-01", "concentration_response", "concentration", "no accumulation declared as increasing fragility"))
    return out


IMPLEMENTS = {
    "ASSETS-3.2-01": ("property_right_conditional", "PARTIAL", "The §5 conditions are declared events."),
    "ASSETS-4-02": ("no_grant_on_sole_basis", "IMPLEMENTED", None),
    "ASSETS-7-01": ("concentration_response", "PARTIAL", "The trigger is a declared flag: thresholds are not given (H-PR-2; "
                    "reclassified l8_parameter)."),
    "ASSETS-9-01": ("critical_assets_designated", "PARTIAL", "Non-Privatizable vs Conditionally Privatizable per category is declared "
                    "(H-PR-1)."),
    # returned to work after the reading of the Codex-draft open points (review of checkpoint 6)
    # clear parts of provisions whose open point remains (reading record, partial_check; review КТ7-GPT-01)
    "ASSETS-4-01": ("grant_on_all_four_conditions", "PARTIAL", "Clear part only: all four conditions as declared values; projections and capacity tests stay open."),
    "ASSETS-1-02": ("no_axiom_bypass_or_override", "PARTIAL", "Clear part only: no axiomatic bypass or upstream override; externalized harm (system boundary) stays open."),
    "ASSETS-2-01": ("downstream_of_ptl", "PARTIAL", "Clear part only: data flow from upstream layers into ASSETS; 'above' and 'alongside' stay open."),
    "ASSETS-5-01": ("justice_condition_persists", "PARTIAL", "Clear part only: the non-negative Justice condition; 'restitution satisfied' stays open."),
    "ASSETS-6-01": ("transfer_keeps_attribution", "PARTIAL", "Clear part only: transfers keep the responsible Subject; the system boundary stays open."),
    "ASSETS-7-02": ("threshold_from_impact", "PARTIAL", "Clear part only: metamorphic basis of a stand-in threshold; the derivation stays open (H-PR-2)."),
    "ASSETS-9-02": ("commons_always_revocable", "PARTIAL", "Clear part only: always revocable; 'strict stewardship conditions' stay open."),
    "ASSETS-1-01": ("property_is_conditional_allocation", "PARTIAL", "Contribution and bounds are the declared §4 conditions."),
    "ASSETS-5-02": ("failure_triggers_degradation", "PARTIAL", "Failures are declared events; any of the three responses counts."),
    "ASSETS-12-01": ("ownership_registered_auditable_bound", "PARTIAL", "Registration and public audit are register entries; binding = an identified Subject."),
    "ASSETS-13-01": ("no_cross_layer_override", "PARTIAL", "Observed as waivers, overrides or discretionary grants recorded by ASSETS."),
}


class PropertyRightsModule(LabModule):
    id = "property_rights"
    version = "1.4.0"
    title = {"en": "Property rights: granting, conditions, critical assets", "ru": "Права собственности: выдача, условия, критические активы"}
    summary = {"en": "Subjects ask for property rights. Are rights granted only under the ASSETS conditions, never on possession "
                     "alone, kept only while the conditions hold, and are water, air and commons held only in revocable stewardship?",
               "ru": "Субъекты просят права собственности. Выдаются ли права только при условиях ASSETS, а не по одному владению, "
                     "сохраняются ли лишь пока выполняются условия, держатся ли вода, воздух и общие блага только в отзывном управлении?"}
    protocols = ["DKP-2-ASSETS-001"]
    example_order = ["five_requests", "all_critical_non_privatizable", "faulty_property"]
    implements = IMPLEMENTS
    tests = ["tests/lab/test_property_rights_module.py"]
    hypotheses = [
        {"id": "H-PR-1", "source": "hypothesis", "text": {
            "en": "§9 lists the categories designated Non-Privatizable or Conditionally Privatizable without assigning them; "
                  "the designation is declared per category.",
            "ru": "§9 перечисляет категории, отнесённые к Non-Privatizable или Conditionally Privatizable, не распределяя их; "
                  "отнесение объявляется для каждой категории."}},
        {"id": "H-PR-2", "source": "missing", "text": {
            "en": "§7 concentration thresholds are 'derived from impact metrics' but not given; whether an accumulation triggers §7 "
                  "is a declared flag.",
            "ru": "Пороги концентрации §7 'выводятся из метрик воздействия', но не заданы; срабатывание §7 — объявленный признак."}},
    ]
    inputs = {
        "horizon_days": {"type": "int", "min": 1, "max": 3650, "default": 10, "unit": "DTI-Day", "source": "user",
                         "label": {"en": "DTI-Days", "ru": "DTI-дней"}},
        "requests": {"type": "list", "min_items": 0, "max_items": 30, "items": REQUEST, "default": REQUESTS_DEFAULT, "source": "user",
                     "label": {"en": "Requests for Property Rights (§4 conditions declared)", "ru": "Запросы прав собственности (условия §4 объявлены)"}},
        "holdings": {"type": "list", "min_items": 0, "max_items": 30, "items": HOLDING, "default": HOLDINGS_DEFAULT, "source": "user",
                     "label": {"en": "Accumulations (§7 trigger declared, H-PR-2)", "ru": "Накопления (срабатывание §7 объявлено, H-PR-2)"}},
        "transfers": {"type": "list", "min_items": 0, "max_items": 30, "items": TRANSFER, "default": [], "source": "user",
                      "label": {"en": "Transfers of granted rights {request, to, day}", "ru": "Передачи выданных прав {request, to, day}"}},
        "critical_designation": {"type": "object", "source": "hypothesis",
                                 "fields": {c: {"type": "enum", "values": ["non_privatizable", "conditionally_privatizable"],
                                                "default": "conditionally_privatizable"} for c in CRITICAL},
                                 "default": {c: "conditionally_privatizable" for c in CRITICAL},
                                 "label": {"en": "Designation of §9 categories (H-PR-1)", "ru": "Отнесение категорий §9 (H-PR-1)"}},
        "faults": {"type": "list", "min_items": 0, "max_items": len(FAULTS), "items": {"type": "enum", "values": list(FAULTS)},
                   "default": [], "source": "user",
                   "label": {"en": "Deliberate faults (counterexamples)", "ru": "Намеренные ошибки (контрпримеры)"},
                   "help": {"en": "; ".join(f"{k}: {v}" for k, v in FAULTS.items()),
                            "ru": "Каждая ошибка отключает одно правило, чтобы показать, что проверка её ловит."}},
    }

    def validate(self, value: Dict[str, Any]) -> Dict[str, Any]:
        r = super().validate(value)
        p = []
        ids = [q["id"] for q in r["requests"]]
        if len(set(ids)) != len(ids):
            p.append("input.requests: repeated id")
        if len(set(r["faults"])) != len(r["faults"]):
            p.append("input.faults: repeated fault")
        if p:
            raise LabInputError(p)
        return r

    def evaluate(self, r: Dict[str, Any]) -> ModuleResult:
        log = run(r)
        res = checks(r, log)
        msgs = log.messages()
        granted = sorted(m.value["request"] for m in msgs if m.source == "ASSETS" and m.kind == "decision" and m.value["granted"])
        refused = sorted(m.value["request"] for m in msgs if m.source == "ASSETS" and m.kind == "decision" and not m.value["granted"])
        outputs = {"granted": granted, "refused": refused,
                   "messages": [m.as_dict() for m in msgs][:300],
                   "event_log": {"time_unit": log.time_unit, "messages": len(log), "digest": log.digest()}}
        explain = [{"en": f"Granted: {', '.join(granted) or 'none'}; refused: {', '.join(refused) or 'none'}.",
                    "ru": f"Выдано: {', '.join(granted) or 'нет'}; отказано: {', '.join(refused) or 'нет'}."}]
        return ModuleResult(outputs=outputs, checks=res, explain=explain)

    def comparison_metrics(self, outputs: Dict[str, Any]) -> Dict[str, Any]:
        return {"granted": len(outputs["granted"]), "refused": len(outputs["refused"])}

    def examples(self) -> Dict[str, Dict[str, Any]]:
        return {
            "five_requests": {},
            "all_critical_non_privatizable": {"critical_designation": {c: "non_privatizable" for c in CRITICAL}},
            "transfer_of_a_right": {"transfers": [{"request": "q1", "to": "coop_b", "day": 2}]},
            "faulty_property": {"faults": ["absolute_right", "grant_by_possession", "privatize_commons", "ignore_concentration"]},
        }

    def failure_examples(self) -> Dict[str, Dict[str, Any]]:
        return {"repeated_request": {"requests": [{"id": "q", "subject": "s", "asset": "a"}] * 2},
                "unknown_basis": {"requests": [{"id": "q", "subject": "s", "asset": "a", "basis": "conquest"}]}}


for _q in REQUESTS_DEFAULT:
    _q.update(resolve(_q, REQUEST["fields"]))
for _h in HOLDINGS_DEFAULT:
    _h.update(resolve(_h, HOLDING["fields"]))
