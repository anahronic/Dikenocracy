"""
CRISIS AND RECOVERY module — scenario S-LAB-06.

DKP-3-DEFENSE-001 (D0–D3, escalation, Resource Recovery Claim, wind-down) and DKP-4-ERROR-001
(systemic error escalation) → DKP-4-CRISIS-001 (PTL-anchored triggers, C0–C4, allowed and
prohibited actions, algorithmic governance, automatic exit, sequential recovery, transparency,
§12 epistemic classification, non-precedent) → exit to DKP-4-UPGRADE-001 or partition.
DKP-7-SCOPE-001 constraints are added when its registry entries exist.

What the texts leave open is declared, not assumed silently:
  * "sustained" D3 has no duration: CRISIS §6 forbids numbers in the protocol and defers them to
    DKP-8-SIMULATION-001, which gives none (open question Q-029); the duration is an input
    marked `missing`, and DEFENSE §5 ("mandatory escalation" at D3) is shown against it (F-010);
  * transitions among C1–C4 are not specified: hypothesis H-CR-1 maps the number and kind of
    active triggers to a state.
"""

from __future__ import annotations

import re
from typing import Any, Dict, List

from lab.core.bus import EventLog, Message, epistemic_problems
from lab.core.checks import FAIL, NOT_APPLICABLE, PASS, UNKNOWN, CheckResult
from lab.core.module import LabModule, ModuleResult
from lab.core.run import canonical_json, sha256_text
from lab.core.schema import LabInputError
from lab.modules.time import canonical, dy_doy

import os

HOURS_PER_DAY = 24
TRIGGERS = ("d3", "error_cascade", "ptl_divergence", "multi_domain")
FAULTS = {
    "forecast_entry": "crisis entered on a forecast before any PTL-confirmed trigger",
    "emergency_authority": "a discretionary emergency authority is granted to a group",
    "suspend_ptl_logging": "PTL logging is suspended during the crisis",
    "unlogged_human": "a human intervention is not logged as an external perturbation",
    "status_priority": "rationing gives priority by social status",
    "delayed_collapse": "crisis authority persists after the exit conditions hold",
    "finance_early": "financial execution resumes before Justice closes crisis claims",
    "valid_crisis_output": "crisis outputs are labelled VALID / SUFFICIENT_DATA",
    "cite_precedent": "a post-crisis decision cites a crisis action as justification",
    "no_broadcast": "no Final State Vector Broadcast in C3",
    "stale_confirmation": "crisis actions continue without refreshed PTL confirmation",
    "upgrade_during_crisis": "a protocol upgrade is activated while the crisis lasts",
    "elevate_scope": "the crisis restricts public expression, an S2 domain",
    "missing_metadata": "crisis suspensions are issued without epistemic metadata",
    "transfer_interpretation": "the A1 interpretation of rationing is attributed to an emergency council",
    "parameter_by_decree": "the crisis authority duration is set by a governance decision",
    "expand_envelope": "a crisis action outside the declared Crisis Scope Envelope is executed",
    "extrapolate_scope": "a crisis action is applied outside the declared Crisis Scope (another region)",
    "crisis_interpretation_rule": "after the crisis, a crisis action is recorded as an interpretation rule for normal operation",
    "crisis_new_obligation": "the crisis defines a new obligation for Subjects",
    "normal_despite_trigger": "the state is reported as C0 while a confirmed crisis condition is present",
    "numeric_in_text": "the CRISIS text checked contains a numerical authority limit (a mutated copy of the pinned text)",
    "conceal_action": "a crisis action is executed without an audit commitment",
    "permanent_control": "the crisis is kept after its exit conditions hold",
    "utilitarian_rationing": "rationing prioritizes Subjects by perceived utility",
    "human_directed_action": "a crisis action is directed by a human coordinator instead of protocol logic",
    # checkable cores of provisions whose open point remains (review КТ7-GPT-01)
    "unescalated_d3_entry": "crisis is entered on D3 although DEFENSE sent no escalation",
    "optimization_objective": "rationing states efficiency and growth as its purpose",
    "a1_interpretation_after_exit": "after the exit a routine decision interprets the A1 minimum required conditions",
}
SIX_ACTIONS = ("suspend_non_essential", "ration", "isolate_failing_subsystem", "activate_reserves",
               "freeze_non_critical_transitions", "prioritize_continuity", "crisis_mercy_mode")          # CRISIS §6 list
OPTIMIZATION = ("optimization", "efficiency", "growth")                                             # CRISIS §1
# CRISIS §1: the Crisis Scope Envelope lies inside S1; SCOPE §3 lists what S1 includes.  Lab table (H-CR-5).
ACTION_DOMAIN = {"suspend_non_essential": "S1: temporary suspension of non-essential functions",
                 "ration": "S1: emergency prioritization bounded by Axiom A1",
                 "freeze_non_critical_transitions": "S1: temporary suspension of non-essential functions",
                 "restrict_public_expression": "S2: cultural expression and symbolic systems"}
ENVELOPE_ACTIONS = ("suspend_non_essential", "ration", "freeze_non_critical_transitions")       # CRISIS §6 items the lab models
A1_FIELDS = {"interpretation_type": "CRISIS_BOUNDED", "interpretation_authority": "DKP-4-CRISIS-001",
             "authority_transferable": False, "post_crisis_audit": "MANDATORY"}                     # CRISIS §12.2


MINIMAL_CASE = {"d3_window": [0, 0], "error_cascade_window": [10, 30], "ptl_divergence_window": [0, 0],
                "multi_domain_window": [0, 0], "confirmation_gap_window": [0, 0], "error_correction_complete_step": 32,
                "identifiable_harm_source": False, "human_intervention_step": -1}
_SNAP = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "corpus", "world-aad3e86", "Dikenocracy")
INJECTED = "Crisis authority lapses after 72 hours."           # fault numeric_in_text: a mutated copy, never the pinned text


def crisis_text() -> str:
    with open(os.path.join(_SNAP, "Protocols", "L4_FailSafe", "DKP-4-CRISIS-001.md"), encoding="utf-8") as f:
        return f.read()


def numeric_quantities(text: str) -> List[str]:
    """Numbers in a protocol text that are not identifiers, labels, section numbers or edition dates (CRISIS §6)."""
    out = []
    for i, line in enumerate(text.splitlines(), 1):
        x = re.sub(r"^\s*#{1,6}\s*[\d.]*", "", line)                                   # heading numbers
        x = re.sub(r"DKP-\d-[A-Z0-9-]+?-\d{3}(?:-[A-Z]+)?", "", x, flags=re.I)          # protocol identifiers
        x = re.sub(r"(?:\bSection|§)\s*[\d.]*\d", "", x)                                # section references
        x = re.sub(r"\b[ACDLST]\d\b", "", x)                                           # A1, C0-C4, D3, L0-L8, S1, T3
        x = re.sub(r"\b\d{4}-\d{2}-\d{2}\b", "", x)                                     # edition dates
        x = re.sub(r"SHA-?256(?:SUMS)?", "", x)
        for m in re.finditer(r"\d+(?:[.,]\d+)?\s*(?:%|percent|hours?|days?|minutes?|seconds?)?", x):
            out.append(f"line {i}: {m.group(0).strip()}")
    return out


def in_window(w, k):
    return int(w[0]) <= k < int(w[1])


def crisis_state(active: List[str]) -> str:
    """H-CR-1: no trigger -> C0; PTL divergence or three or more triggers -> C3; two -> C2; one -> C1."""
    if not active:
        return "C0"
    if "ptl_divergence" in active or len(active) >= 3:
        return "C3"
    return "C2" if len(active) == 2 else "C1"


def run(r: Dict[str, Any]):
    faults = set(r["faults"])
    log = EventLog("hour", tie_rule="observation < evaluation < decision < action < notice; then event_id")
    order = {"observation": 0, "evaluation": 1, "decision": 2, "action": 3, "notice": 4}
    n = {"i": 0}
    commits: Dict[str, str] = {}

    def dti(k):
        d = r["start_dti_day"] + k // HOURS_PER_DAY
        return {"dti_day": d, "dy": canonical(*dy_doy(d))}

    def put(kind, source, k, value, prov=(), epistemic=None):
        n["i"] += 1
        eid = f"{source.lower().replace('/', '-')}-{k:04d}-{n['i']:05d}"
        m = log.append(Message(event_id=eid, kind=kind, source=source, arrived_at=k,
                               measured_at=k if kind == "observation" else None,
                               decided_at=k if kind in ("decision", "action") else None,
                               value=value, epistemic=epistemic, provenance=tuple(prov), order=order[kind]))
        if kind == "action" and not (conceal[0] and source == "CRISIS"):
            commits[eid] = sha256_text(canonical_json(m.as_dict()))
        conceal[0] = False
        return m

    conceal = [False]
    blocked_noted = [False]
    d3_run = 0
    entry_step = [None]
    in_crisis = False
    state = "C0"
    exit_step = None
    crisis_actions: List[str] = []
    claims_open = False
    authority_until = None
    broadcast_done = False
    layers_active = {"L0": True, "L1": True, "L2": True}
    rows = []
    for k in range(r["horizon_steps"]):
        confirmed = not in_window(r["confirmation_gap_window"], k)
        flags = {"d3": in_window(r["d3_window"], k), "error_cascade": in_window(r["error_cascade_window"], k),
                 "ptl_divergence": in_window(r["ptl_divergence_window"], k),
                 "multi_domain": in_window(r["multi_domain_window"], k)}
        ptl = None
        if not (in_crisis and "suspend_ptl_logging" in faults):
            ptl = put("observation", "PTL", k, {"confirmed": confirmed, **flags, **dti(k)})
        # DEFENSE: D3 only with refreshed confirmation; escalation request at D3
        level = "D3" if flags["d3"] and confirmed else ("D0" if not flags["d3"] else "D0")
        dmsg = put("evaluation", "DEFENSE", k, {"level": level, **dti(k)}, [ptl.event_id] if ptl else [])
        if level == "D3":
            d3_run += 1
            if d3_run == 1 and "unescalated_d3_entry" not in faults:
                put("notice", "DEFENSE", k, {"escalate_to": "DKP-4-CRISIS-001"}, [dmsg.event_id])
                if r["identifiable_harm_source"]:
                    put("notice", "DEFENSE", k, {"resource_recovery_claim": "routed to DKP-1-JUSTICE-001"}, [dmsg.event_id])
                    claims_open = True
        else:
            d3_run = 0
        if flags["error_cascade"] and confirmed:
            put("notice", "ERROR", k, {"escalate_to": "DKP-4-CRISIS-001", "reason": "systemic cascading error"},
                [ptl.event_id] if ptl else [])
        need = r["sustained_d3_steps"] if r["d3_reading"] == "sustained" else 1
        active = [t for t in TRIGGERS if (t == "d3" and d3_run >= need) or (t != "d3" and flags[t] and confirmed)]
        if "forecast_entry" in faults and not in_crisis and any(in_window(r[f"{t}_window"], k + 3) for t in TRIGGERS) \
                and not active:
            active = ["forecast"]
        # Q-065: §4 lists the triggers; §0 and §2 ask for L3 escalation.  'l3_escalation_required' admits an entry only
        # while an L3 escalation (here DEFENSE at D3) is in effect; 'trigger_sufficient' enters on any §4 trigger
        if r["entry_reading"] == "l3_escalation_required" and not in_crisis and active and d3_run == 0:
            if not blocked_noted[0]:
                put("notice", "CRISIS", k, {"entered": False, "pending_triggers": list(active), "reading": r["entry_reading"],
                                            "reason": "no L3 escalation (CRISIS §0, §2)", "question": "Q-065"},
                    [ptl.event_id] if ptl else [])
                blocked_noted[0] = True
            active = []
        exit_ok = not active and (not r["error_cascade_window"][1] > r["error_cascade_window"][0]
                                  or 0 <= r["error_correction_complete_step"] <= k)
        prev_state = state
        if active:
            in_crisis = True
            state = crisis_state([a for a in active if a != "forecast"]) if active != ["forecast"] else "C1"
        elif in_crisis and exit_ok and confirmed and "permanent_control" not in faults:
            in_crisis, state, exit_step = False, "C0", k
            if "delayed_collapse" in faults:
                authority_until = k + 6
        md = {"validity_state": "CONDITIONAL", "confidence_state": "SUFFICIENT_DATA" if confirmed else "DEGRADED_SIGNAL",
              "consistency_state": "ORACLE_CONFLICT" if flags["ptl_divergence"] else "CONSISTENT",
              "scope_ref": f"DKP-4-CRISIS-001:{state}", "revalidation_required": True, "dispute_allowed": True}
        if "valid_crisis_output" in faults:
            md = {**md, "validity_state": "VALID", "confidence_state": "SUFFICIENT_DATA"}
        shown = "C0" if "normal_despite_trigger" in faults and in_crisis and entry_step[0] is not None \
            and k == entry_step[0] + 1 else state
        cmsg = put("evaluation", "CRISIS", k, {"state": shown, "active_triggers": active, **dti(k)},
                   [ptl.event_id] if ptl else [], epistemic=md if state != "C0" else None)
        if in_crisis:
            if entry_step[0] is None:
                entry_step[0] = k
                put("notice", "CRISIS", k, {"envelope": sorted(r["crisis_envelope"]), "scope": r["crisis_scope_region"]},
                    [cmsg.event_id])
                if "crisis_new_obligation" in faults:
                    put("notice", "CRISIS", k, {"defines": "obligation", "content": "mandatory labour service for all Subjects"},
                        [cmsg.event_id])
                if "parameter_by_decree" in faults:
                    put("notice", "GOVERNANCE", k, {"parameter": "crisis authority duration", "value_hours": 720,
                                                    "set_by": "governance decision"}, [cmsg.event_id])
            if confirmed or "stale_confirmation" in faults:
                region = r["crisis_scope_region"]
                conceal[0] = "conceal_action" in faults and k == entry_step[0]
                a = put("action", "CRISIS", k, {"action": "suspend_non_essential", "state": state, "time_limited": True,
                                                "reversible": True, "ends_at_exit": True, "scope": region, **dti(k)},
                        [cmsg.event_id], epistemic=None if "missing_metadata" in faults else md)
                crisis_actions.append(a.event_id)
                rule = "status" if "status_priority" in faults else "utility" if "utilitarian_rationing" in faults \
                    else r["allocation_rule"]
                a1 = {**md, **A1_FIELDS, "interprets": "Axiom A1 minimum required conditions"}
                if "transfer_interpretation" in faults:
                    a1.update(interpretation_authority="emergency council", authority_transferable=True)
                if r["a1_confidence_reading"] == "not_sufficient" and a1["confidence_state"] == "SUFFICIENT_DATA":
                    a1["confidence_state"] = "DEGRADED_SIGNAL"                       # §12.3 reading: no value is named (F-043)
                put("action", "CRISIS", k, {"action": "ration", "rule": rule,
                                            "purpose": "efficiency and growth" if "optimization_objective" in faults
                                            else "life and core execution",
                                            "scope": "R2" if "extrapolate_scope" in faults and k == entry_step[0] + 1 else region,
                                            **dti(k)}, [cmsg.event_id], epistemic=a1)
                if "expand_envelope" in faults and k == entry_step[0]:
                    put("action", "CRISIS", k, {"action": "freeze_non_critical_transitions", "state": state, "scope": region,
                                                **dti(k)}, [cmsg.event_id], epistemic=md)
                if "human_directed_action" in faults and k == entry_step[0] + 2:
                    put("action", "CRISIS", k, {"action": "suspend_non_essential", "state": state, "time_limited": True,
                                                "reversible": True, "ends_at_exit": True, "scope": region,
                                                "directed_by": "crisis coordinator", **dti(k)}, [ptl.event_id] if ptl else [],
                        epistemic=md)
                if "elevate_scope" in faults and k == entry_step[0]:
                    put("action", "CRISIS", k, {"action": "restrict_public_expression", "state": state, "scope": region, **dti(k)},
                        [cmsg.event_id], epistemic=md)
            if state in ("C3", "C4") and not broadcast_done and "no_broadcast" not in faults:
                put("notice", "CRISIS", k, {"final_state_vector_broadcast": "external isolated archives"}, [cmsg.event_id])
                broadcast_done = True
            if "emergency_authority" in faults:
                put("notice", "GOVERNANCE", k, {"authority": "emergency council", "discretionary": True}, [cmsg.event_id])
            layers_active.update(L1=False, L2=False)
        if in_crisis and "upgrade_during_crisis" in faults and k == r["d3_window"][0] + 8:
            put("notice", "UPGRADE", k, {"activation": "emergency patch", "crisis_state": state}, [cmsg.event_id])
        if k == r["human_intervention_step"]:
            if "unlogged_human" in faults:
                put("action", "HUMAN", k, {"intervention": "manual rerouting"}, [cmsg.event_id])
            else:
                put("notice", "CRISIS", k, {"external_perturbation": "human intervention", "post_crisis_audit": True},
                    [cmsg.event_id])
        if authority_until is not None and k < authority_until:
            put("notice", "GOVERNANCE", k, {"authority": "crisis authority", "after_exit": True}, [cmsg.event_id])
        # sequential recovery after exit: L0 -> L1 -> L2; finance waits for Justice closure of crisis claims
        if exit_step is not None and not in_crisis:
            if k == exit_step:
                put("notice", "RECOVERY", k, {"reactivate": "L0", "pathway": r["exit_pathway"]}, [cmsg.event_id])
            if k == exit_step + 1:
                put("notice", "RECOVERY", k, {"reactivate": "L1"}, [cmsg.event_id])
                layers_active["L1"] = True
            if k >= exit_step + 2 and not layers_active["L2"]:
                closed = not claims_open or (0 <= r["justice_closure_step"] <= k)
                if closed or "finance_early" in faults:
                    put("notice", "RECOVERY", k, {"reactivate": "L2", "finance": "resumes",
                                                  "claims_closed": closed}, [cmsg.event_id])
                    layers_active["L2"] = True
            if k == r["upgrade_activation_step"] and r["exit_pathway"] == "upgrade":
                put("notice", "UPGRADE", k, {"activation": "DKP-4-UPGRADE-001 pathway", "crisis_state": state}, [cmsg.event_id])
            if k == r["post_crisis_decision_step"]:
                prov = [cmsg.event_id] + (crisis_actions[:1] if "cite_precedent" in faults else [])
                put("decision", "GOVERNANCE", k, {"decision": "routine allocation", "justification": "protocol rules"}, prov)
                if "a1_interpretation_after_exit" in faults:
                    put("decision", "GOVERNANCE", k, {"decision": "routine allocation", "scope": r["crisis_scope_region"],
                                                      "interprets": "Axiom A1 minimum required conditions"}, [cmsg.event_id])
                if "crisis_interpretation_rule" in faults and crisis_actions:
                    put("notice", "INTERPRETATION", k, {"interpretation_rule": "crisis rationing is acceptable governance practice",
                                                        "derived_from": crisis_actions[0]}, [crisis_actions[0]])
        rows.append({"step": k, "state": shown, "defense": level, "active_triggers": active, "confirmed": confirmed,
                     "layers": dict(layers_active)})
    return log, rows, commits, {"exit_step": exit_step, "claims_open": claims_open}


def checks(r, log: EventLog, rows, commits, info) -> List[CheckResult]:
    msgs = log.messages()
    out: List[CheckResult] = []
    crisis_steps = [x["step"] for x in rows if x["state"] != "C0"]

    def v(rid, chk, bad, ok, no, ev=None):
        e = dict(ev or {})
        if bad:
            e["violations"] = bad[:10]
        return CheckResult(rid, chk, FAIL if bad else PASS, no.format(n=len(bad)) if bad else ok, evidence=e)

    def na(rid, chk, what, why):
        return CheckResult(rid, chk, NOT_APPLICABLE, what, applicability=why)

    ptl = {m.arrived_at: m for m in msgs if m.source == "PTL"}
    trig_ok = lambda k: k in ptl and ptl[k].value["confirmed"] and any(ptl[k].value[t] for t in TRIGGERS)
    # entry ---------------------------------------------------------------------------
    entries = [x["step"] for i, x in enumerate(rows) if x["state"] != "C0" and (i == 0 or rows[i - 1]["state"] == "C0")]
    if entries:
        bad = [k for k in entries if not trig_ok(k)]
        out.append(v("CRISIS-4-02", "no_discretionary_entry", bad, "every crisis entry follows a PTL-confirmed trigger",
                     "{n} crisis entries without a PTL-confirmed trigger (forecast or discretion)"))
        d3_entry = [k for k in entries if "d3" in rows[k]["active_triggers"]]
        if d3_entry:
            first_d3 = min(x["step"] for x in rows if x["defense"] == "D3")
            out.append(CheckResult("CRISIS-4-01", "ptl_confirmed_triggers", UNKNOWN,
                                   f"entry on 'sustained D3' needs a duration the corpus does not give (Q-029); computed "
                                   f"with {r['sustained_d3_steps'] if r['d3_reading'] == 'sustained' else 1} step(s): "
                                   f"DEFENSE escalated at step {first_d3}, crisis entered at step {d3_entry[0]} (F-010)",
                                   evidence={"defense_escalation": first_d3, "crisis_entry": d3_entry[0]}))
        else:
            out.append(v("CRISIS-4-01", "ptl_confirmed_triggers", bad,
                         "crisis entered on PTL-confirmed triggers listed in §4", "{n} entries on unlisted triggers"))
    else:
        out.append(na("CRISIS-4-02", "no_discretionary_entry", "crisis entry", "no crisis in this experiment"))
        out.append(na("CRISIS-4-01", "ptl_confirmed_triggers", "crisis entry", "no crisis in this experiment"))
    # §5 C0: no crisis condition present (recomputed from the PTL observations) and no crisis action
    cond, run_len = {}, 0
    need = r["sustained_d3_steps"] if r["d3_reading"] == "sustained" else 1
    l3_only = r["entry_reading"] == "l3_escalation_required"
    was = False
    for x in rows:
        p = ptl.get(x["step"])
        ok = bool(p and p.value["confirmed"])
        run_len = run_len + 1 if ok and p.value["d3"] else 0
        other = ok and any(p.value[t] for t in TRIGGERS if t != "d3")
        # under 'l3_escalation_required' a §4 trigger without L3 escalation is not a condition for leaving C0 (Q-065)
        cond[x["step"]] = run_len >= need or (other and (not l3_only or run_len > 0 or was))
        was = x["state"] != "C0"
    c0 = {x["step"] for x in rows if x["state"] == "C0"}
    bad = [f"step {k}: C0 with a confirmed crisis condition" for k in sorted(c0) if cond[k]]
    bad += [f"{m.event_id}: crisis action in a C0 step" for m in msgs if m.source == "CRISIS" and m.kind == "action" and m.arrived_at in c0]
    out.append(v("CRISIS-5-02", "c0_without_conditions", bad,
                 f"C0 held in {len(c0)} steps, none with a confirmed crisis condition or a crisis action",
                 "{n} C0 steps with crisis conditions or crisis actions"))
    # §6 Non-Precedent Rule: no numerical values in this protocol (the pinned text; a mutated copy under the fault)
    text = crisis_text() + ("\n" + INJECTED if "numeric_in_text" in r["faults"] else "")
    nums = numeric_quantities(text)
    out.append(v("CRISIS-Non-PrecedentRule_-03", "no_numbers_in_protocol", nums,
                 "the pinned DKP-4-CRISIS-001 defines no numerical value, threshold, coefficient, timer, decay curve or "
                 "quantitative authority limit (identifiers, state labels, section numbers and edition dates excluded)",
                 "{n} numerical quantities in the CRISIS text"))
    bad = [x["step"] for x in rows if x["state"] not in ("C0", "C1", "C2", "C3", "C4")] + \
          [m.event_id for m in msgs if m.source == "CRISIS" and m.kind == "evaluation" and "dti_day" not in m.value]
    out.append(v("CRISIS-5-01", "finite_dti_states", bad, "crisis states are C0–C4, each indexed by DTI-Day",
                 "{n} states outside C0–C4 or without DTI index"))
    if not crisis_steps:
        for rid, chk in (("CRISIS-5-07", "persistence_needs_confirmation"), ("CRISIS-7-01", "logging_no_authority"),
                         ("CRISIS-7-03", "no_status_priority"), ("CRISIS-7-04", "allocation_basis"),
                         ("CRISIS-6-04", "action_qualities"), ("CRISIS-10-01", "actions_anchored_committed"),
                         ("CRISIS-12.1-01", "conditional_outputs"), ("CRISIS-12.1-02", "scope_ref_flags"),
                         ("CRISIS-10-02", "final_state_broadcast"), ("CRISIS-9-01", "automatic_exit"),
                         ("CRISIS-9-05", "immediate_collapse"), ("CRISIS-9-02", "sequential_recovery"),
                         ("CRISIS-Non-PrecedentRule_-01", "no_precedent"), ("CRISIS-8-02", "human_logged"),
                         ("CRISIS-1-04", "envelope_in_s1"), ("CRISIS-2-03", "ptl_anchored"), ("CRISIS-12-01", "eb5_metadata"),
                         ("CRISIS-12.2-01", "a1_interpretation_fields"), ("CRISIS-12.3-01", "no_settled_axiom_interpretation"),
                         ("CRISIS-Non-PrecedentRule_-04", "parameters_from_simulation"), ("CRISIS-1-03", "envelope_not_expanded"),
                         ("CRISIS-2-05", "no_extrapolation"), ("CRISIS-2-02", "no_new_rights_obligations"),
                         ("CRISIS-7-02", "no_concealment_permanence_utility"), ("CRISIS-8-01", "algorithmic_governance"),
                         ("CRISIS-0-03", "no_precedent_or_future_authorization"), ("CRISIS-0-02", "no_new_powers_temporary"),
                         ("CRISIS-1-02", "within_envelope_subset_of_scope"), ("CRISIS-2-04", "within_scope_applicability")):
            out.append(na(rid, chk, "crisis execution", "no crisis in this experiment"))
        return out + defense_checks(r, log, rows, msgs, v, na) + core_checks(r, msgs, rows, v, na)
    cs = set(crisis_steps)
    actions = [m for m in msgs if m.kind == "action" and m.source == "CRISIS"]
    unconfirmed = [m.event_id for m in actions if not rows[m.arrived_at]["confirmed"]]
    out.append(v("CRISIS-5-07", "persistence_needs_confirmation", unconfirmed,
                 "crisis actions only in steps with refreshed PTL confirmation", "{n} crisis actions without refreshed confirmation"))
    gaps = [k for k in cs if k not in ptl]
    authority = [m.event_id for m in msgs if m.source == "GOVERNANCE" and m.kind == "notice" and m.arrived_at in cs]
    out.append(v("CRISIS-7-01", "logging_no_authority", gaps + authority,
                 "PTL logging continued in every crisis step; no discretionary authority granted",
                 "{n} crisis steps without PTL logging or with a discretionary authority"))
    rations = [m for m in actions if m.value.get("action") == "ration"]
    out.append(v("CRISIS-7-03", "no_status_priority", [m.event_id for m in rations if m.value["rule"] in ("status", "utility")],
                 "no allocation by social status, historical impact or perceived utility", "{n} allocations by status"))
    out.append(v("CRISIS-7-04", "allocation_basis", [m.event_id for m in rations if m.value["rule"] not in ("egalitarian", "proximity")],
                 f"allocation is {r['allocation_rule']} (egalitarian minimum or physical proximity)",
                 "{n} allocations on another basis"))
    bad = [m.event_id for m in actions if m.value.get("action") == "suspend_non_essential"
           and not (m.value["time_limited"] and m.value["reversible"] and m.value["ends_at_exit"])]
    out.append(v("CRISIS-6-04", "action_qualities", bad, "crisis actions are time-limited, reversible and audited",
                 "{n} crisis actions not time-limited or not reversible"))
    bad = [m.event_id for m in actions if not m.provenance or "dti_day" not in m.value
           or commits.get(m.event_id) != sha256_text(canonical_json(m.as_dict()))]
    out.append(v("CRISIS-10-01", "actions_anchored_committed", bad,
                 "every crisis action is PTL-anchored (provenance), DTI-indexed and committed (digest)",
                 "{n} crisis actions not anchored, indexed or committed"))
    outs = [m for m in msgs if m.source == "CRISIS" and m.epistemic is not None]
    propagated = {k: ("SUFFICIENT_DATA" if x["confirmed"] else "DEGRADED_SIGNAL") for k, x in enumerate(rows)}
    a1 = [m for m in actions if m.value.get("action") == "ration"]
    not_cond = [m.event_id for m in outs if m.epistemic["validity_state"] != "CONDITIONAL"]
    not_prop = [m.event_id for m in outs if m.epistemic["confidence_state"] != propagated[m.arrived_at]]
    a1_ids = {m.event_id for m in a1}
    if not_prop and not not_cond and set(not_prop) <= a1_ids:
        out.append(CheckResult("CRISIS-12.1-01", "conditional_outputs", FAIL,
                               f"{len(not_prop)} A1 outputs do not carry the propagated confidence ({propagated[log.get(not_prop[0]).arrived_at]}): "
                               "§12.3 forbids SUFFICIENT_DATA for them and names no other value (F-043, reading 'not_sufficient')",
                               evidence={"tag": "rule_conflict", "finding": "F-043", "violations": not_prop[:10]}))
    else:
        out.append(v("CRISIS-12.1-01", "conditional_outputs", not_cond + not_prop,
                     "every crisis output is CONDITIONAL and carries the confidence propagated from the PTL signals of its hour",
                     "{n} crisis outputs not CONDITIONAL or not carrying the propagated confidence"))
    # §1 envelope in S1, §2 PTL anchoring, §12 metadata (EB §5), §12.2 A1 fields, §12.3 no settled interpretation
    out.append(v("CRISIS-1-04", "envelope_in_s1", [m.event_id for m in actions if not ACTION_DOMAIN.get(m.value.get("action"), "").startswith("S1")],
                 "every crisis action falls in an S1 category of SCOPE §3 (H-CR-5)", "{n} crisis actions outside S1"))

    # §1 envelope declared at entry, never expanded; §2 nothing reused outside the declared Crisis Scope
    env = [m for m in msgs if m.source == "CRISIS" and m.value.get("envelope") is not None]
    declared = set(env[0].value["envelope"]) if env else set()
    bad = ([] if len(env) == 1 else [f"{len(env)} envelope declarations"]) + \
          [f"{m.event_id}: {m.value['action']} outside the declared envelope" for m in actions if m.value.get("action") not in declared]
    out.append(v("CRISIS-1-03", "envelope_not_expanded", bad,
                 f"one Crisis Scope Envelope declared at entry ({', '.join(sorted(declared))}); every crisis action within it",
                 "{n} crisis actions outside the declared envelope or envelope changes"))
    region = env[0].value["scope"] if env else None
    out.append(v("CRISIS-2-05", "no_extrapolation", [f"{m.event_id}: applied to {m.value.get('scope')}" for m in actions
                                                     if m.value.get("scope") != region],
                 f"every crisis action applied within the declared Crisis Scope ({region})",
                 "{n} crisis actions applied outside the declared Crisis Scope"))
    defined = [f"{m.event_id}: defines {m.value['defines']}" for m in msgs if m.source == "CRISIS" and m.value.get("defines")]
    granted = [m.event_id for m in msgs if m.source == "GOVERNANCE" and m.value.get("authority") and m.arrived_at in cs]
    out.append(v("CRISIS-2-02", "no_new_rights_obligations", defined + granted,
                 "the crisis defined no right, obligation or authority and redefined no axiom",
                 "{n} rights, obligations or authorities introduced by the crisis"))
    exitable = {x["step"]: (x["step"] in ptl and not cond[x["step"]] and x["confirmed"] and
                            (not r["error_cascade_window"][1] > r["error_cascade_window"][0]
                             or 0 <= r["error_correction_complete_step"] <= x["step"])) for x in rows}
    kept = [f"step {x['step']}: crisis kept after the exit conditions held" for i, x in enumerate(rows)
            if i and x["state"] != "C0" and rows[i - 1]["state"] != "C0" and exitable[x["step"]]]
    hidden = [f"{m.event_id}: no audit commitment" for m in actions if m.event_id not in commits]
    utility = [f"{m.event_id}: rationing by {m.value['rule']}" for m in rations if m.value["rule"] == "utility"]
    out.append(v("CRISIS-7-02", "no_concealment_permanence_utility", hidden + kept[:1] + utility,
                 "every crisis action committed for audit; the crisis ended when its exit conditions held; no utilitarian "
                 "valuation of life", "{n} concealed actions, retained control or utilitarian valuations"))
    derived = [m.event_id for m in actions if m.value.get("directed_by")
               or not any(log.get(p).source == "CRISIS" and log.get(p).kind == "evaluation" for p in m.provenance)]
    humans = [m.event_id for m in msgs if m.source == "HUMAN" and m.kind == "action"]
    out.append(v("CRISIS-8-01", "algorithmic_governance", derived + granted + humans,
                 f"all {len(actions)} crisis actions derive from the CRISIS state determination (protocol logic); no emergency "
                 "human authority", "{n} crisis actions not derived from protocol logic, or emergency human authority"))

    def anchored(m):
        seen, todo = set(), list(m.provenance)
        while todo:
            p = todo.pop()
            if p in seen:
                continue
            seen.add(p)
            q = log.get(p)
            if q.source == "PTL":
                return True
            todo += list(q.provenance)
        return False
    ev_c = [m for m in msgs if m.source == "CRISIS" and m.kind == "evaluation" and m.value["state"] != "C0"]
    out.append(v("CRISIS-2-03", "ptl_anchored", [m.event_id for m in ev_c + actions if not anchored(m)],
                 f"{len(ev_c)} crisis determinations and {len(actions)} actions trace back to a PTL observation",
                 "{n} crisis determinations or actions without PTL anchoring"))
    out.append(v("CRISIS-12-01", "eb5_metadata", [m.event_id for m in ev_c + actions if epistemic_problems(m.epistemic)],
                 "every crisis determination and output carries complete EPISTEMIC-BOUNDARIES §5 metadata",
                 "{n} crisis determinations or outputs without complete metadata"))
    out.append(v("CRISIS-12.2-01", "a1_interpretation_fields",
                 [m.event_id for m in a1 if any((m.epistemic or {}).get(f) != x for f, x in A1_FIELDS.items())],
                 f"{len(a1)} rationing outputs (A1 minimum conditions, H-CR-4) carry CRISIS_BOUNDED, authority DKP-4-CRISIS-001 "
                 "(not transferable) and a mandatory post-crisis audit", "{n} A1 outputs with wrong or transferred interpretation fields")
               if a1 else na("CRISIS-12.2-01", "a1_interpretation_fields", "A1 interpretations", "no rationing output"))
    valid = [m.event_id for m in a1 if (m.epistemic or {}).get("validity_state") == "VALID"]
    suff = [m.event_id for m in a1 if (m.epistemic or {}).get("confidence_state") == "SUFFICIENT_DATA" and m.event_id not in valid]
    if not a1:
        out.append(na("CRISIS-12.3-01", "no_settled_axiom_interpretation", "axiom interpretations", "no rationing output"))
    elif valid:
        out.append(v("CRISIS-12.3-01", "no_settled_axiom_interpretation", valid + suff, "", "{n} A1 outputs labelled VALID"))
    elif suff:
        out.append(CheckResult("CRISIS-12.3-01", "no_settled_axiom_interpretation", FAIL,
                               f"{len(suff)} A1 outputs carry SUFFICIENT_DATA, propagated from confirmed PTL signals as §12.1 requires; "
                               "§12.3 forbids it and names no other value (F-043, reading 'propagated')",
                               evidence={"tag": "rule_conflict", "finding": "F-043", "violations": suff[:10]}))
    else:
        out.append(CheckResult("CRISIS-12.3-01", "no_settled_axiom_interpretation", PASS,
                               f"none of {len(a1)} A1 outputs carries VALID or SUFFICIENT_DATA"))
    decree = [m.event_id for m in msgs if m.source == "GOVERNANCE" and m.value.get("parameter")]
    out.append(v("CRISIS-Non-PrecedentRule_-04", "parameters_from_simulation", decree, "", "{n} crisis parameters set outside SIMULATION")
               if decree else CheckResult("CRISIS-Non-PrecedentRule_-04", "parameters_from_simulation", UNKNOWN,
                                          f"no parameter is set outside SIMULATION, but none is validated under it either: the lab's "
                                          f"'sustained' D3 = {r['sustained_d3_steps']} h, revalidation every hour and exit on the first "
                                          "hour without triggers are declared values; no SIMULATION calibration exists (F-014)",
                                          evidence={"declared": {"sustained_d3_steps": r["sustained_d3_steps"], "revalidation": "every step",
                                                                 "exit_sensitivity": "first step without an active trigger"}}))
    out.append(v("CRISIS-12.1-02", "scope_ref_flags", [m.event_id for m in outs if epistemic_problems(m.epistemic)
                 or not m.epistemic["scope_ref"].startswith("DKP-4-CRISIS-001:C") or m.epistemic["revalidation_required"] is not True
                 or m.epistemic["dispute_allowed"] is not True],
                 "crisis outputs carry scope_ref DKP-4-CRISIS-001:C[n], revalidation_required and dispute_allowed TRUE",
                 "{n} crisis outputs with wrong metadata"))
    c3 = [x["step"] for x in rows if x["state"] in ("C3", "C4")]
    if c3:
        sent = any(m.value.get("final_state_vector_broadcast") for m in msgs if m.source == "CRISIS")
        out.append(v("CRISIS-10-02", "final_state_broadcast", [] if sent else c3[:1],
                     "Final State Vector Broadcast initiated in C3", "no Final State Vector Broadcast in C3/C4"))
    else:
        out.append(na("CRISIS-10-02", "final_state_broadcast", "Final State Vector Broadcast", "no C3 or C4 state"))
    human = [m for m in msgs if m.source == "HUMAN"]
    if r["human_intervention_step"] >= 0:
        logged = [m for m in msgs if m.value and m.value.get("external_perturbation")]
        out.append(v("CRISIS-8-02", "human_logged", [m.event_id for m in human] if not logged else [],
                     "the human intervention is logged as an external perturbation for post-crisis audit",
                     "{n} human interventions executed without being logged as perturbations"))
    else:
        out.append(na("CRISIS-8-02", "human_logged", "human intervention", "no human intervention declared"))
    ex = info["exit_step"]
    if ex is not None:
        # independent: first step after the last crisis step where no trigger is active and ERROR correction is complete
        out.append(v("CRISIS-9-01", "automatic_exit", [] if rows[ex - 1]["state"] != "C0" else [ex],
                     f"crisis terminated automatically at step {ex}, when the exit conditions were confirmed",
                     "exit not at the confirmed restoration"))
        lingering = [m.event_id for m in msgs if m.source == "GOVERNANCE" and m.kind == "notice" and m.arrived_at >= ex]
        out.append(v("CRISIS-9-05", "immediate_collapse", lingering, "all crisis authority ended at the exit step",
                     "{n} notices of crisis authority after exit"))
        rec = {m.value["reactivate"]: m.arrived_at for m in msgs if m.source == "RECOVERY"}
        order_ok = rec.get("L0", -1) <= rec.get("L1", 10 ** 9) <= rec.get("L2", 10 ** 9)
        fin = [m for m in msgs if m.source == "RECOVERY" and m.value.get("reactivate") == "L2"]
        early = [m.event_id for m in fin if info["claims_open"] and not m.value["claims_closed"]]
        out.append(v("CRISIS-9-02", "sequential_recovery", ([] if order_ok else ["order"]) + early,
                     "recovery L0 → L1 → L2; finance resumed only after Justice closed crisis claims",
                     "{n} violations of sequential recovery or early finance"))
        cited = [m.event_id for m in msgs if m.kind == "decision" and m.source == "GOVERNANCE"
                 and any(log.get(p).kind == "action" and log.get(p).source == "CRISIS" for p in m.provenance)]
        out.append(v("CRISIS-Non-PrecedentRule_-01", "no_precedent", cited,
                     "no post-crisis decision cites a crisis action", "{n} post-crisis decisions cite crisis actions"))
        crisis_ids = {m.event_id for m in actions}
        after = [m for m in msgs if m.arrived_at >= ex and m.source not in ("PTL", "AUDIT")]
        later = [f"{m.event_id}: cites a crisis action" for m in after if crisis_ids & set(m.provenance)]
        later += [f"{m.event_id}: interpretation rule" for m in after if m.value.get("interpretation_rule")]
        later += [f"{m.event_id}: authority after exit" for m in after if m.source == "GOVERNANCE" and m.value.get("authority")]
        out.append(v("CRISIS-0-03", "no_precedent_or_future_authorization", later,
                     "after the crisis nothing cites a crisis action, no interpretation rule or custom is recorded from it, and no "
                     "authorization outlives it", "{n} precedents, interpretation rules or authorizations outliving the crisis"))
    else:
        for rid, chk in (("CRISIS-9-01", "automatic_exit"), ("CRISIS-9-05", "immediate_collapse"),
                         ("CRISIS-9-02", "sequential_recovery"), ("CRISIS-Non-PrecedentRule_-01", "no_precedent"),
                         ("CRISIS-0-03", "no_precedent_or_future_authorization")):
            out.append(na(rid, chk, "crisis exit", "the crisis does not end within the horizon"))
    # returned to work after the reading of the Codex-draft open points (review of checkpoint 6)
    ex = info["exit_step"]
    after = [m for m in msgs if ex is not None and m.arrived_at >= ex]
    outlive = [f"{m.event_id}: authority after exit" for m in after if m.source == "GOVERNANCE" and m.value.get("authority")]
    out.append(v("CRISIS-0-02", "no_new_powers_temporary", defined + granted + outlive,
                 "the crisis created no right, obligation or authority, and its constraints ended with it",
                 "{n} new powers or constraints outliving the crisis"))
    non_s1 = [f"{m.event_id}: {m.value.get('action')} is {ACTION_DOMAIN.get(m.value.get('action'), 'unclassified')}"
              for m in actions if not ACTION_DOMAIN.get(m.value.get("action"), "").startswith("S1")]
    env_bad = [f"envelope item {a} outside S1" for a in sorted(declared) if not ACTION_DOMAIN.get(a, "").startswith("S1")]
    env_bad += [f"{m.event_id}: {m.value['action']} outside the declared envelope" for m in actions
                if m.value.get("action") not in declared]
    out.append(v("CRISIS-1-02", "within_envelope_subset_of_scope", env_bad + non_s1,
                 f"all {len(actions)} crisis actions within the declared envelope, itself inside S1 of DKP-7-SCOPE-001",
                 "{n} crisis actions or envelope items outside the envelope or outside S1"))
    elsewhere = [f"{m.event_id}: applied to {m.value.get('scope')}" for m in actions if m.value.get("scope") != region]
    norms = [f"{m.event_id}: interpretation rule" for m in after if m.value.get("interpretation_rule")]
    norms += [f"{m.event_id}: cites a crisis action" for m in after if m.kind == "decision"
              and {a.event_id for a in actions} & set(m.provenance)]
    out.append(v("CRISIS-2-04", "within_scope_applicability", non_s1 + elsewhere + defined + outlive + norms,
                 "crisis execution stayed within SCOPE: S1 only, in the declared region, no new rights, no authority beyond "
                 "the crisis, no precedent", "{n} extensions of applicability beyond DKP-7-SCOPE-001"))
    return out + defense_checks(r, log, rows, msgs, v, na) + core_checks(r, msgs, rows, v, na)


SCOPE_MIRRORS = [("CRISIS-4-02", "SCOPE-5-02", "crisis_entry_by_state_machine"),
                 ("CRISIS-9-05", "SCOPE-5-12", "exit_collapses_to_s0"),
                 ("CRISIS-9-05", "SCOPE-6-04", "stabilization_restores_baseline"),
                 ("CRISIS-Non-PrecedentRule_-01", "SCOPE-3-08", "s1_no_precedent"),
                 ("CRISIS-6-04", "SCOPE-3-04", "s1_time_limited")]


def scope_mirrors(results: List[CheckResult]) -> List[CheckResult]:
    """SCOPE §3, §5, §6 constrain the same crisis execution; each mirrors one CRISIS check."""
    by = {c.requirement_id: c for c in results}
    out = []
    for src, rid, chk in SCOPE_MIRRORS:
        c = by[src]
        out.append(CheckResult(rid, chk, c.status, f"{c.explanation} (as checked for {src})", evidence=c.evidence,
                               applicability=c.applicability))
    return out


def core_checks(r, msgs, rows, v, na) -> List[CheckResult]:
    """Clear parts of provisions whose open point remains (reading record, partial_check; review КТ7-GPT-01)."""
    from lab.core.checks import UNKNOWN as _U
    out: List[CheckResult] = []
    entries = [x["step"] for i, x in enumerate(rows) if x["state"] != "C0" and (i == 0 or rows[i - 1]["state"] == "C0")]
    esc = sorted(m.arrived_at for m in msgs if m.source == "DEFENSE" and m.value.get("escalate_to") == "DKP-4-CRISIS-001")

    def escalated(k):                 # a DEFENSE escalation sent in the D3 run that is current at step k
        start = k
        while start > 0 and rows[start - 1]["defense"] == "D3":
            start -= 1
        return any(start <= e <= k for e in esc) and rows[k]["defense"] == "D3"
    d3e = [k for k in entries if "d3" in rows[k]["active_triggers"]]
    if d3e:
        bad = [f"step {k}: entered on D3 without a DEFENSE escalation" for k in d3e if not escalated(k)]
        for rid, chk, ok in (("CRISIS-0-01", "l3_escalation_on_d3_entry", "every entry on D3 carries the L3 (DEFENSE) escalation"),
                             ("CRISIS-2-01", "defense_escalation_on_d3_entry", "every entry on D3 follows a DEFENSE escalation")):
            out.append(v(rid, chk, bad, ok + f" ({len(d3e)} entr{'y' if len(d3e) == 1 else 'ies'}; T3 is not modelled here)",
                         "{n} entries on D3 without escalation"))
    else:
        for rid, chk in (("CRISIS-0-01", "l3_escalation_on_d3_entry"), ("CRISIS-2-01", "defense_escalation_on_d3_entry")):
            out.append(na(rid, chk, "entry on D3", "no crisis entry on D3"))
    # the open part (Q-065): entry on a §4 trigger without any L3 escalation, under either reading
    bare = [k for k in entries if not escalated(k)]
    held = [m for m in msgs if m.source == "CRISIS" and m.value.get("entered") is False]
    if bare:
        out.append(CheckResult("CRISIS-0-01", "entry_without_l3_escalation", _U,
                               f"crisis entered at step {bare[0]} on {rows[bare[0]]['active_triggers']} with no L3 escalation: §4 is met; "
                               "§0 ('downstream L3 escalation') and §2 ('only upon escalation from DKP-3-DEFENSE-001 or equivalent L3 "
                               "containment protocols') are met only if such an entry needs no L3 escalation (Q-065)",
                               evidence={"entries": bare, "reading": r["entry_reading"]}))
    elif held:
        out.append(CheckResult("CRISIS-0-01", "entry_without_l3_escalation", _U,
                               f"crisis not entered although {held[0].value['pending_triggers']} is PTL-confirmed (ERROR escalates under "
                               "its §9): §0 and §2 are met; §4 ('SHALL be entered') is met only if it also requires L3 escalation (Q-065)",
                               evidence={"held_at": held[0].arrived_at, "reading": r["entry_reading"]}))
    else:
        out.append(na("CRISIS-0-01", "entry_without_l3_escalation", "entry without L3 escalation",
                      "every crisis entry had an L3 escalation" if entries else "no §4 trigger without L3 escalation"))
    acts = [m for m in msgs if m.source == "CRISIS" and m.kind == "action"]
    if acts:
        bad = [f"{m.event_id}: {m.value.get('purpose') or m.value.get('objective')}" for m in acts
               if any(w in str(m.value.get("purpose", "")) + str(m.value.get("objective", "")) for w in OPTIMIZATION)]
        out.append(v("CRISIS-1-01", "no_optimization_objective", bad,
                     f"{len(acts)} crisis actions; none states optimization, efficiency or growth as its objective",
                     "{n} crisis actions aiming at optimization, efficiency or growth"))
        out.append(v("CRISIS-6-01", "actions_in_section_6", [f"{m.event_id}: {m.value['action']}" for m in acts
                                                               if m.value.get("action") not in SIX_ACTIONS],
                     f"all {len(acts)} crisis actions are kinds listed in §6", "{n} crisis actions outside the §6 list"))
        ration = [m for m in acts if m.value.get("action") == "ration"]
        out.append(v("CRISIS-6-02", "rationing_for_life", [m.event_id for m in ration if m.value.get("purpose") != "life and core execution"],
                     f"{len(ration)} rationing acts, each citing life and core execution", "{n} rationing acts for another purpose")
                   if ration else na("CRISIS-6-02", "rationing_for_life", "rationing", "no rationing"))
    else:
        for rid, chk in (("CRISIS-1-01", "no_optimization_objective"), ("CRISIS-6-01", "actions_in_section_6"),
                         ("CRISIS-6-02", "rationing_for_life")):
            out.append(na(rid, chk, "crisis actions", "no crisis action"))
    # §9 with SCOPE §5: the crisis state never persists after a confirmed exit
    if entries:
        ecw = r["error_cascade_window"]
        bad = []
        for i, x in enumerate(rows):
            if i == 0 or rows[i - 1]["state"] == "C0" or x["active_triggers"] or not x["confirmed"]:
                continue
            if ecw[1] > ecw[0] and not 0 <= r["error_correction_complete_step"] <= x["step"]:
                continue
            if x["state"] != "C0":
                bad.append(f"step {x['step']}: {x['state']} after the exit conditions hold")
        bad += [f"{m.event_id}: crisis authority after the exit" for m in msgs if m.source == "GOVERNANCE" and m.value.get("after_exit")]
        out.append(v("CRISIS-9-04", "no_persistence_after_exit", bad,
                     "the crisis state and its authorities ended at the step the exit conditions were PTL-confirmed",
                     "{n} crisis states or authorities persisting after a confirmed exit"))
    else:
        out.append(na("CRISIS-9-04", "no_persistence_after_exit", "crisis exit", "no crisis in this experiment"))
    # §7 A1 Interpretation Constraint: only inside the declared Crisis Scope
    a1 = [m for m in msgs if (m.epistemic or {}).get("interprets") == "Axiom A1 minimum required conditions"
          or m.value.get("interprets") == "Axiom A1 minimum required conditions"]
    state = {x["step"]: x["state"] for x in rows}
    bad = [f"{m.event_id}: outside the crisis" for m in a1 if state.get(m.arrived_at, "C0") == "C0"]
    bad += [f"{m.event_id}: scope {m.value.get('scope')}" for m in a1 if m.value.get("scope") != r["crisis_scope_region"]]
    out.append(v("CRISIS-AxiomA1InterpretationConstraint-01", "a1_interpretation_in_scope", bad,
                 f"{len(a1)} interpretations of the A1 minimum required conditions, all inside the declared Crisis Scope "
                 f"({r['crisis_scope_region']}, crisis steps)", "{n} A1 interpretations outside the declared Crisis Scope")
               if a1 else na("CRISIS-AxiomA1InterpretationConstraint-01", "a1_interpretation_in_scope", "A1 interpretation",
                             "no record interprets the A1 minimum required conditions"))
    return out


def defense_checks(r, log, rows, msgs, v, na) -> List[CheckResult]:
    out = []
    # ERROR §9: a systemic or cascading error escalates to CRISIS automatically
    lo, hi = r["error_cascade_window"]
    if hi > lo:
        esc = [m.arrived_at for m in msgs if m.source == "ERROR" and m.value.get("escalate_to")]
        first = next((x["step"] for x in rows if lo <= x["step"] < hi and x["confirmed"]), None)
        out.append(v("ERROR-9-05", "systemic_error_escalates", [] if first is None or (esc and esc[0] == first) else [first],
                     "the cascading error escalated to CRISIS at its first confirmed hour", "no automatic escalation"))
    else:
        out.append(na("ERROR-9-05", "systemic_error_escalates", "systemic error escalation", "no cascading error"))
    # UPGRADE §2, §11: no upgrade operation while a crisis state C1-C4 holds
    ups = [m for m in msgs if m.source == "UPGRADE"]
    bad = [m.event_id for m in ups if rows[m.arrived_at]["state"] != "C0"]
    for rid, chk in (("UPGRADE-2-05", "no_upgrade_in_crisis"), ("UPGRADE-11-01", "no_emergency_upgrade")):
        out.append(v(rid, chk, bad, f"{len(ups)} upgrade activation(s), none during a crisis state" if ups else
                     "no upgrade operation during the crisis", "{n} upgrade operations during a crisis state"))
    d3 = [x["step"] for x in rows if x["defense"] == "D3"]
    if d3:
        esc = [m.arrived_at for m in msgs if m.source == "DEFENSE" and m.kind == "notice" and m.value.get("escalate_to")]
        out.append(v("DEFENSE-9-01", "escalation_to_crisis", [] if esc and esc[0] == d3[0] else [d3[0]],
                     f"Defense requested escalation to CRISIS at the first D3 step ({d3[0]})", "no escalation at D3"))
        unconf = [k for k in d3 if not rows[k]["confirmed"]]
        out.append(v("DEFENSE-5-02", "d3_needs_confirmation", unconf, "D3 held only with refreshed PTL confirmation",
                     "{n} D3 steps without confirmation"))
        if r["identifiable_harm_source"]:
            claim = [m for m in msgs if m.source == "DEFENSE" and m.value.get("resource_recovery_claim")]
            out.append(v("DEFENSE-8-02", "resource_recovery_claim", [] if claim else [d3[0]],
                         "an identifiable harm source produced a Resource Recovery Claim routed to JUSTICE",
                         "no Resource Recovery Claim"))
        else:
            out.append(na("DEFENSE-8-02", "resource_recovery_claim", "Resource Recovery Claim", "no identifiable harm source"))
        after = [x["step"] for x in rows if x["step"] > d3[-1] and x["defense"] != "D0"]
        out.append(v("DEFENSE-8-04", "wind_down", after, "Defense wound down when the harm stream ceased",
                     "{n} steps of defense after the harm ceased"))
    else:
        for rid, chk in (("DEFENSE-9-01", "escalation_to_crisis"), ("DEFENSE-5-02", "d3_needs_confirmation"),
                         ("DEFENSE-8-02", "resource_recovery_claim"), ("DEFENSE-8-04", "wind_down")):
            out.append(na(rid, chk, "defense escalation", "no D3 state in this experiment"))
    return out


IMPLEMENTS = {
    # clear parts of provisions whose open point remains (reading record, partial_check; review КТ7-GPT-01)
    "CRISIS-0-01": ("l3_escalation_on_d3_entry", "PARTIAL", "Clear part only: entries on D3 carry the L3 escalation; entry on another §4 trigger without L3 escalation gives UNKNOWN (Q-065); T3 is not modelled."),
    "CRISIS-2-01": ("defense_escalation_on_d3_entry", "PARTIAL", "Clear part only: entries on D3 follow a DEFENSE escalation; 'equivalent L3 containment protocols' stays open (Q-065)."),
    "CRISIS-1-01": ("no_optimization_objective", "PARTIAL", "Clear part only: no action aims at optimization, efficiency or growth; the priority order stays open."),
    "CRISIS-6-01": ("actions_in_section_6", "PARTIAL", "Clear part only: action kinds from the §6 list; whether the list is closed stays open."),
    "CRISIS-6-02": ("rationing_for_life", "PARTIAL", "Clear part only: rationing cites life and core execution; 'strict' stays open."),
    "CRISIS-9-04": ("no_persistence_after_exit", "PARTIAL", "Clear part only: no state or authority after a confirmed exit; validated PTL windows stay open."),
    "CRISIS-AxiomA1InterpretationConstraint-01": ("a1_interpretation_in_scope", "PARTIAL", "Clear part only: A1 interpretation only inside the declared Crisis Scope; the scope's SCOPE definition stays open."),
    "CRISIS-4-01": ("ptl_confirmed_triggers", "PARTIAL", "'Sustained' has no duration (Q-029); D3 entry gives UNKNOWN (F-010)."),
    "CRISIS-4-02": ("no_discretionary_entry", "IMPLEMENTED", None),
    "CRISIS-5-01": ("finite_dti_states", "PARTIAL", "Transitions among C1–C4 are a hypothesis (H-CR-1)."),
    "CRISIS-5-07": ("persistence_needs_confirmation", "PARTIAL", "Revalidation cadence is not defined (Q-029)."),
    "CRISIS-6-04": ("action_qualities", "PARTIAL", "Proportionality to the threat is not measurable here."),
    "CRISIS-7-01": ("logging_no_authority", "IMPLEMENTED", None),
    "CRISIS-7-03": ("no_status_priority", "IMPLEMENTED", None),
    "CRISIS-7-04": ("allocation_basis", "IMPLEMENTED", None),
    "CRISIS-8-02": ("human_logged", "IMPLEMENTED", None),
    "CRISIS-9-01": ("automatic_exit", "PARTIAL", "Exit conditions are scenario inputs confirmed by PTL messages."),
    "CRISIS-9-02": ("sequential_recovery", "IMPLEMENTED", None),
    "CRISIS-9-05": ("immediate_collapse", "IMPLEMENTED", None),
    "CRISIS-10-01": ("actions_anchored_committed", "IMPLEMENTED", None),
    "CRISIS-10-02": ("final_state_broadcast", "PARTIAL", "The broadcast is a logged notice; the external archive is not modelled."),
    "CRISIS-12.1-01": ("conditional_outputs", "PARTIAL", "Confidence and consistency are propagated from the scenario's PTL flags."),
    "CRISIS-12.1-02": ("scope_ref_flags", "IMPLEMENTED", None),
    "CRISIS-Non-PrecedentRule_-01": ("no_precedent", "PARTIAL", "Precedent is detected as citation (provenance) of a crisis action."),
    "CRISIS-0-03": ("no_precedent_or_future_authorization", "PARTIAL", "Observed after the exit: citations of crisis actions, recorded "
                    "interpretation rules, authority notices. Custom formed without a record is not observable."),
    "CRISIS-1-03": ("envelope_not_expanded", "PARTIAL", "The envelope is a declared list of §6 actions (input crisis_envelope)."),
    "CRISIS-2-02": ("no_new_rights_obligations", "PARTIAL", "Observed as explicit definitions and authority notices."),
    "CRISIS-2-05": ("no_extrapolation", "PARTIAL", "The Crisis Scope is a declared region; reuse in another region is observed."),
    "CRISIS-5-02": ("c0_without_conditions", "IMPLEMENTED", None),
    # returned to work after the reading of the Codex-draft open points (review of checkpoint 6)
    "CRISIS-0-02": ("no_new_powers_temporary", "PARTIAL", "Powers are observed as definitions and authority notices; 'temporarily' as nothing outliving the exit."),
    "CRISIS-1-02": ("within_envelope_subset_of_scope", "PARTIAL", "The envelope is a declared list of §6 actions; S1 membership per SCOPE §3 (H-CR-5)."),
    "CRISIS-2-04": ("within_scope_applicability", "PARTIAL", "SCOPE §3-§5 boundaries observed as S1 membership, the declared region, new rights, outliving authority and precedent."),
    "CRISIS-Non-PrecedentRule_-03": ("no_numbers_in_protocol", "IMPLEMENTED", None),
    "CRISIS-7-02": ("no_concealment_permanence_utility", "PARTIAL", "Permanence observed as staying in crisis once the module's exit "
                    "conditions hold; 'emergency governance' as authority notices (also §7, §9)."),
    "CRISIS-8-01": ("algorithmic_governance", "IMPLEMENTED", None),
    "DEFENSE-5-02": ("d3_needs_confirmation", "IMPLEMENTED", None),
    "DEFENSE-8-02": ("resource_recovery_claim", "IMPLEMENTED", None),
    "DEFENSE-8-04": ("wind_down", "PARTIAL", "Admissible-state restoration is the end of the harm window."),
    "DEFENSE-9-01": ("escalation_to_crisis", "IMPLEMENTED", None),
    "ERROR-9-05": ("systemic_error_escalates", "PARTIAL", "'Protocol-defined threshold' of affected Subjects is not modelled; the cascade is a declared window."),
    "UPGRADE-2-05": ("no_upgrade_in_crisis", "IMPLEMENTED", None),
    "UPGRADE-11-01": ("no_emergency_upgrade", "IMPLEMENTED", None),
    "SCOPE-5-02": ("crisis_entry_by_state_machine", "IMPLEMENTED", None),
    "SCOPE-5-12": ("exit_collapses_to_s0", "IMPLEMENTED", None),
    "SCOPE-6-04": ("stabilization_restores_baseline", "PARTIAL", "Baseline = absence of crisis authority notices after exit."),
    "SCOPE-3-08": ("s1_no_precedent", "PARTIAL", "Precedent detected as citation of a crisis action."),
    "SCOPE-3-04": ("s1_time_limited", "PARTIAL", "Crisis actions end at exit; no numeric time limit exists (Q-029)."),
    "CRISIS-1-04": ("envelope_in_s1", "PARTIAL", "Actions are classified into SCOPE §3 categories by a lab table (H-CR-5)."),
    "CRISIS-2-03": ("ptl_anchored", "IMPLEMENTED", None),
    "CRISIS-12-01": ("eb5_metadata", "IMPLEMENTED", None),
    "CRISIS-12.2-01": ("a1_interpretation_fields", "PARTIAL", "Rationing is read as the A1 minimum-conditions interpretation (H-CR-4)."),
    "CRISIS-12.3-01": ("no_settled_axiom_interpretation", "PARTIAL", "Conflicts with §12.1 when PTL confidence is SUFFICIENT_DATA (F-043)."),
    "CRISIS-Non-PrecedentRule_-04": ("parameters_from_simulation", "PARTIAL", "No SIMULATION calibration exists (F-014): UNKNOWN unless a parameter is set elsewhere."),
}


class CrisisRecoveryModule(LabModule):
    id = "crisis_recovery"
    version = "1.4.0"
    title = {"en": "Crisis and recovery (S-LAB-06)", "ru": "Кризис и восстановление (S-LAB-06)"}
    summary = {"en": "An existential threat or a cascading failure: does the system enter crisis only on PTL evidence, "
                     "keep logging, grant no one power, leave by itself and recover layer by layer?",
               "ru": "Угроза существованию или каскадный отказ: входит ли система в кризис только по данным PTL, "
                     "продолжает ли журнал, не даёт ли кому-то власти, выходит ли сама и восстанавливается по слоям?"}
    protocols = ["DKP-4-CRISIS-001", "DKP-3-DEFENSE-001", "DKP-4-ERROR-001", "DKP-4-UPGRADE-001", "DKP-7-SCOPE-001"]
    example_order = ["d3_sustained", "d3_immediate", "a1_confidence_not_sufficient", "cascade_and_divergence", "faulty_crisis",
                     "faulty_crisis_outputs", "no_crisis"]
    alternative_examples = ["d3_immediate", "a1_confidence_not_sufficient", "error_cascade_l3_required"]
    implements = IMPLEMENTS
    tests = ["tests/lab/test_crisis_recovery_module.py"]
    causal_note = None
    hypotheses = [
        {"id": "H-CR-1", "source": "hypothesis", "text": {
            "en": "Crisis state from active triggers: none C0; one C1; two C2; PTL divergence or three or more C3. "
                  "C4 is not entered automatically. The text names the states but not their transitions.",
            "ru": "Состояние кризиса по активным триггерам: нет — C0; один — C1; два — C2; расхождение PTL или три и "
                  "более — C3. C4 автоматически не наступает. Текст называет состояния, но не переходы."}},
        {"id": "H-CR-2", "source": "missing", "text": {
            "en": "'Sustained' D3 = D3 for the declared number of steps; the corpus gives no duration (CRISIS §6 forbids "
                  "numbers and defers them to DKP-8-SIMULATION-001).",
            "ru": "'Устойчивое' D3 = D3 в течение объявленного числа шагов; корпус длительности не даёт (CRISIS §6 "
                  "запрещает числа и отсылает к DKP-8-SIMULATION-001)."}},
        {"id": "H-CR-3", "source": "alternative", "text": {
            "en": "'immediate' reading: crisis is entered at the first D3 step, as DEFENSE §5 ('mandatory escalation') "
                  "would require; 'sustained' is the CRISIS §4 wording.",
            "ru": "Прочтение 'immediate': кризис наступает на первом шаге D3, как требовал бы DEFENSE §5 "
                  "('обязательная эскалация'); 'sustained' — формулировка CRISIS §4."}},
        {"id": "H-CR-4", "source": "hypothesis", "text": {
            "en": "Rationing to the baseline survival minimum (§7) is an output that interprets 'minimum required conditions' "
                  "under Axiom A1 (§12.2).",
            "ru": "Распределение до базового минимума выживания (§7) — выход, толкующий 'minimum required conditions' "
                  "аксиомы A1 (§12.2)."}},
        {"id": "H-CR-5", "source": "hypothesis", "text": {
            "en": "A crisis action stays in S1 when it falls in an S1 category of SCOPE §3 (temporary suspension of non-essential "
                  "functions; emergency prioritization bounded by A1); the classification is a lab table.",
            "ru": "Действие кризиса остаётся в S1, если относится к категории S1 из SCOPE §3 (временная приостановка "
                  "несущественных функций; экстренная приоритизация в рамках A1); классификация — таблица лаборатории."}},
        {"id": "H-CR-7", "source": "alternative", "text": {
            "en": "Entry condition (Q-065): 'trigger_sufficient' (default) enters on any PTL-confirmed §4 trigger; "
                  "'l3_escalation_required' also asks for an L3 escalation in effect (§0, §2), so an ERROR cascade or a PTL "
                  "divergence alone does not enter.",
            "ru": "Условие входа (Q-065): 'trigger_sufficient' (по умолчанию) — вход по любому подтверждённому PTL триггеру §4; "
                  "'l3_escalation_required' — дополнительно нужна действующая эскалация L3 (§0, §2), поэтому каскад ERROR или "
                  "расхождение PTL сами по себе не ведут ко входу."}},
        {"id": "H-CR-6", "source": "alternative", "text": {
            "en": "Confidence of A1 outputs (F-043): 'propagated' carries the PTL confidence as §12.1 says and breaks §12.3 when "
                  "it is SUFFICIENT_DATA; 'not_sufficient' carries DEGRADED_SIGNAL (no value is named) and breaks §12.1.",
            "ru": "Уверенность выходов A1 (F-043): 'propagated' переносит уверенность PTL, как велит §12.1, и нарушает §12.3 при "
                  "SUFFICIENT_DATA; 'not_sufficient' ставит DEGRADED_SIGNAL (значение не названо) и нарушает §12.1."}},
    ]
    inputs = {
        "start_dti_day": {"type": "int", "min": 0, "max": 10 ** 8, "default": 2461042, "source": "user",
                          "label": {"en": "DTI-Day of step 0", "ru": "DTI-Day шага 0"}},
        "horizon_steps": {"type": "int", "min": 2, "max": 5000, "default": 96, "unit": "h", "source": "user",
                          "label": {"en": "Hours", "ru": "Часов"}},
        "d3_window": {"type": "pair", "min": 0, "max": 10 ** 6, "default": [10, 40], "unit": "h", "source": "user",
                      "label": {"en": "Existential threat (D3) from/to hour", "ru": "Угроза существованию (D3) с/до часа"}},
        "error_cascade_window": {"type": "pair", "min": 0, "max": 10 ** 6, "default": [0, 0], "unit": "h", "source": "user",
                                 "label": {"en": "Cascading systemic error from/to hour", "ru": "Каскадная ошибка с/до часа"}},
        "ptl_divergence_window": {"type": "pair", "min": 0, "max": 10 ** 6, "default": [0, 0], "unit": "h", "source": "user",
                                  "label": {"en": "PTL divergence from/to hour", "ru": "Расхождение PTL с/до часа"}},
        "multi_domain_window": {"type": "pair", "min": 0, "max": 10 ** 6, "default": [0, 0], "unit": "h", "source": "user",
                                "label": {"en": "Multi-domain harm from/to hour", "ru": "Многодоменный вред с/до часа"}},
        "confirmation_gap_window": {"type": "pair", "min": 0, "max": 10 ** 6, "default": [0, 0], "unit": "h", "source": "user",
                                    "label": {"en": "No refreshed PTL confirmation from/to hour", "ru": "Нет подтверждения PTL с/до часа"}},
        "entry_reading": {"type": "enum", "values": ["trigger_sufficient", "l3_escalation_required"], "default": "trigger_sufficient",
                          "source": "alternative", "label": {"en": "Entry condition (H-CR-7, Q-065)", "ru": "Условие входа (H-CR-7, Q-065)"}},
        "d3_reading": {"type": "enum", "values": ["sustained", "immediate"], "default": "sustained", "source": "alternative",
                       "label": {"en": "Crisis entry on D3 (H-CR-3)", "ru": "Вход в кризис при D3 (H-CR-3)"}},
        "sustained_d3_steps": {"type": "int", "min": 1, "max": 10 ** 4, "default": 6, "unit": "h", "source": "missing",
                               "label": {"en": "'Sustained' D3 lasts (H-CR-2; not in the corpus)", "ru": "'Устойчивое' D3 длится (H-CR-2; нет в корпусе)"}},
        "error_correction_complete_step": {"type": "int", "min": -1, "max": 10 ** 6, "default": -1, "unit": "h", "source": "user",
                                           "label": {"en": "ERROR confirms correction at hour (-1: never)",
                                                     "ru": "ERROR подтверждает исправление в час (-1: никогда)"}},
        "identifiable_harm_source": {"type": "bool", "default": True, "source": "user",
                                     "label": {"en": "Identifiable external harm source", "ru": "Источник вреда установлен"}},
        "justice_closure_step": {"type": "int", "min": -1, "max": 10 ** 6, "default": 60, "unit": "h", "source": "user",
                                 "label": {"en": "Justice closes crisis claims at hour (-1: never)",
                                           "ru": "Justice закрывает претензии кризиса в час (-1: никогда)"}},
        "allocation_rule": {"type": "enum", "values": ["egalitarian", "proximity"], "default": "egalitarian", "source": "text",
                            "label": {"en": "Rationing basis (CRISIS §7)", "ru": "Основа распределения (CRISIS §7)"}},
        "human_intervention_step": {"type": "int", "min": -1, "max": 10 ** 6, "default": 20, "unit": "h", "source": "user",
                                    "label": {"en": "Human intervention at hour (-1: none)", "ru": "Вмешательство человека в час (-1: нет)"}},
        "post_crisis_decision_step": {"type": "int", "min": -1, "max": 10 ** 6, "default": 80, "unit": "h", "source": "user",
                                      "label": {"en": "Routine decision after the crisis at hour", "ru": "Обычное решение после кризиса в час"}},
        "upgrade_activation_step": {"type": "int", "min": -1, "max": 10 ** 6, "default": 70, "unit": "h", "source": "user",
                                    "label": {"en": "Upgrade activation at hour (pathway 'upgrade')", "ru": "Активация обновления в час (путь 'upgrade')"}},
        "exit_pathway": {"type": "enum", "values": ["soft_reset", "upgrade", "partition"], "default": "soft_reset", "source": "user",
                         "label": {"en": "Exit pathway (CRISIS §9)", "ru": "Путь выхода (CRISIS §9)"}},
        "a1_confidence_reading": {"type": "enum", "values": ["propagated", "not_sufficient"], "default": "propagated",
                                  "source": "alternative", "label": {"en": "Confidence of A1 outputs (H-CR-6, F-043)",
                                                                     "ru": "Уверенность выходов A1 (H-CR-6, F-043)"}},
        "crisis_envelope": {"type": "list", "min_items": 1, "max_items": len(ENVELOPE_ACTIONS),
                            "items": {"type": "enum", "values": list(ENVELOPE_ACTIONS)}, "default": ["ration", "suspend_non_essential"],
                            "source": "user", "label": {"en": "Declared Crisis Scope Envelope: permitted actions (§1, §6)",
                                                        "ru": "Объявленная оболочка кризиса: разрешённые действия (§1, §6)"}},
        "crisis_scope_region": {"type": "str", "default": "R1", "source": "user",
                                "label": {"en": "Declared Crisis Scope (region)", "ru": "Объявленная область кризиса (регион)"}},
        "faults": {"type": "list", "min_items": 0, "max_items": len(FAULTS), "items": {"type": "enum", "values": list(FAULTS)},
                   "default": [], "source": "user",
                   "label": {"en": "Deliberate faults (counterexamples)", "ru": "Намеренные ошибки (контрпримеры)"},
                   "help": {"en": "; ".join(f"{k}: {v}" for k, v in FAULTS.items()),
                            "ru": "Каждая ошибка отключает одно правило, чтобы показать, что проверка её ловит."}},
    }

    def validate(self, value: Dict[str, Any]) -> Dict[str, Any]:
        r = super().validate(value)
        p = [f"input.{k}: whole hours" for k in ("d3_window", "error_cascade_window", "ptl_divergence_window",
                                                  "multi_domain_window", "confirmation_gap_window")
             if not all(float(x).is_integer() for x in r[k])]
        if len(set(r["faults"])) != len(r["faults"]):
            p.append("input.faults: repeated fault")
        if p:
            raise LabInputError(p)
        return r

    def evaluate(self, r: Dict[str, Any]) -> ModuleResult:
        log, rows, commits, info = run(r)
        res = checks(r, log, rows, commits, info)
        res += scope_mirrors(res)
        states = [x["state"] for x in rows]
        d3 = [x["step"] for x in rows if x["defense"] == "D3"]
        entry = next((x["step"] for x in rows if x["state"] != "C0"), None)
        outputs = {"states": rows, "crisis_hours": sum(1 for s in states if s != "C0"), "max_state": max(states),
                   "defense_escalation_hour": d3[0] if d3 else None, "crisis_entry_hour": entry,
                   "exit_hour": info["exit_step"],
                   "event_log": {"time_unit": log.time_unit, "messages": len(log), "digest": log.digest()}}
        explain = [{"en": f"Crisis in {outputs['crisis_hours']} of {len(rows)} hours; highest state {outputs['max_state']} "
                          f"(H-CR-1); exit at hour {info['exit_step']}.",
                    "ru": f"Кризис {outputs['crisis_hours']} из {len(rows)} часов; наивысшее состояние {outputs['max_state']} "
                          f"(H-CR-1); выход в час {info['exit_step']}."}]
        if d3 and entry is not None and entry > d3[0]:
            explain.append({"en": f"DEFENSE escalated at hour {d3[0]} (D3: 'mandatory escalation'); CRISIS entered at hour "
                                  f"{entry} after 'sustained' D3 of a declared {r['sustained_d3_steps']} h (F-010).",
                            "ru": f"DEFENSE эскалировал в час {d3[0]} (D3: 'обязательная эскалация'); CRISIS наступил в час "
                                  f"{entry} после 'устойчивого' D3 объявленной длительности {r['sustained_d3_steps']} ч (F-010)."})
        return ModuleResult(outputs=outputs, checks=res, explain=explain)

    def comparison_metrics(self, outputs: Dict[str, Any]) -> Dict[str, Any]:
        return {"crisis_hours": outputs["crisis_hours"], "max_state": outputs["max_state"],
                "escalation_to_entry_hours": (outputs["crisis_entry_hour"] - outputs["defense_escalation_hour"])
                if outputs["crisis_entry_hour"] is not None and outputs["defense_escalation_hour"] is not None else None,
                "exit_hour": outputs["exit_hour"]}

    def examples(self) -> Dict[str, Dict[str, Any]]:
        return {
            "d3_sustained": {},
            "d3_immediate": {"d3_reading": "immediate"},
            "cascade_and_divergence": {"d3_window": [0, 0], "error_cascade_window": [10, 30], "ptl_divergence_window": [20, 26],
                                       "error_correction_complete_step": 32, "identifiable_harm_source": False},
            "faulty_crisis": {"faults": ["forecast_entry", "emergency_authority", "status_priority", "delayed_collapse",
                                         "finance_early", "cite_precedent", "unlogged_human"]},
            "faulty_crisis_scope": {"faults": ["expand_envelope", "extrapolate_scope", "crisis_interpretation_rule",
                                               "crisis_new_obligation", "human_directed_action"]},
            "no_crisis": {"d3_window": [0, 0], "human_intervention_step": -1},
            # Q-065 minimal case: a PTL-confirmed ERROR cascade (an execution error, E2), no L3 escalation, nothing else
            "error_cascade_without_l3": dict(MINIMAL_CASE),
            "error_cascade_l3_required": dict(MINIMAL_CASE, entry_reading="l3_escalation_required"),
            "exit_to_upgrade": {"exit_pathway": "upgrade"},
            "a1_confidence_not_sufficient": {"a1_confidence_reading": "not_sufficient"},
            "faulty_crisis_outputs": {"faults": ["elevate_scope", "missing_metadata", "transfer_interpretation", "parameter_by_decree",
                                                 "suspend_ptl_logging"]},
        }

    def failure_examples(self) -> Dict[str, Dict[str, Any]]:
        return {"fractional_window": {"d3_window": [1.5, 3]}, "unknown_fault": {"faults": ["martial_law"]}}
